from linepy import *
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import ChatRoomAnnouncementContents
from akad.ttypes import ChatRoomAnnouncement
from multiprocessing import Pool, Process
from datetime import datetime, timedelta
from time import sleep
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, html5lib, traceback, atexit
import urllib, urllib3
from humanfriendly import format_timespan, format_size, format_number, format_length
from urllib.parse import urlencode
import requests.packages.urllib3.exceptions as urllib3_exceptions
from thrift import transport, protocol, server
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol, server
from threading import Thread
from multiprocessing import Pool, Process
from time import sleep
from bs4 import BeautifulSoup
from random import randint
from Naked.toolshed.shell import execute_js
from urllib.parse import urlencode
from random import randint
#==============<ELANK BOTS>================
print("""\033["""+str(randint(0,1))+""";"""+str(randint(31,36))+"""m█▀ ▄▀█ █▀▄ █ █▀ ▀█▀ █ █▀▀\n▄█ █▀█ █▄▀ █ ▄█ ░█░ █ █▄▄\033[0m""")
print("""\033["""+str(randint(0,1))+""";"""+str(randint(31,36))+"""mBOT Elank_bot\nBy AbhelChand's\033[0m""")
elanks = LINE("richardsusanto.6000@gmail.com","tulungagung123",appName ="DESKTOPWIN\t7.3.1\tWindows\t10")
elanks.log("Auth Token : " + str(elanks.authToken))
#========================================
oepoll = OEPoll(elanks)
creator = ["uc1810aa6facc5a7c33227784312151ff"]
admin = ["uc1810aa6facc5a7c33227784312151ff"]
owner = ["uc1810aa6facc5a7c33227784312151ff"]
staff = ["uc1810aa6facc5a7c33227784312151ff"]
elanksMID = elanks.getProfile().mid
elanks = elanks
elanksProfile = elanks.getProfile()
mid = elanks.getProfile().mid
Keder = [elanks]
Teamelanks = [elanks]
Saints = admin + owner + staff
Team = creator + owner + admin + staff
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)
botlist = [elanks]
Bots = [mid]
botStart = time.time()
#========================================
proName = []
pro_name = []
protectjoin = []
proLink = []
proKick = []
proCancel = []
proInvite = []
ghostJs = []
unsendchat = {}
protectantijs = []
groupName = {}
groupImage = {}
wbanlist = []
welcome = []
msg_dict = {}
msg_dict1 = {}
#========================================
settings = {
    "Picture":False,
    "videoProfile":False,
    "displayName":False,
    "coverId":False,
    "myProfile":False,
    "pictureStatus":False,
    "picture":False,
    "group":{},
    "changeCover":False,
    "changeVideo":False,
    "groupPicture":False,
    "changePicture":False,
    "autoJoinTicket":False,
    "userMention":{},
    "autoJoin": True,
    "mimic": {},
    "target": {},
    "timeRestart": {},
    "server": {},
    "simiSimi":{},
    "rnameComand": {},
    "rname":{},
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}
#========================================
wait = {
    "Limit": 1,
    "owner":{},
    "admin":{},
    "myProfile":{},
    "coverId":{},
    "keyCommand": "",
    "setKey": False,
    "undang":False,
    "changevid":False,
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "limit": 1,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "checkmid": False,
    "getMid": False,
    "invite":False,
    "Invi":False,
    "staff":{},
    "Timeline": False,
    "likePost": False,
    "likeOn": False,
    "responGc": True,
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "readPoint":{},
    "readMember":{},
    "lang":False,
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "BACKUP CANCELL":False,
    "BACKUP KICK":False,
    'pname': {},
    'pnharfbot': {},
    "pro_name": {},
    "lockicon": {},
    "save_icon": {},
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "tumbal":True,
    "backup":True,
    "contact":False,
    "autoRead": False,
    "autoBlock": False,
    "autoJoin":False,
    "spamcall": True,
    "Busy": False,
    "smule": True,
    "ytube": False,
    "autoAdd":False,
    'autoCancel':{"on":True, "members":1},
    "autoReject":False,
    "autoLeave":False,
    "detectMention":True,
    "detectMention2":False,
    "Mentionkick":False,
    "welcomeOn":False,
    "leaveMsg":False,
    "Unsend":False,
    "sticker":False,
    "selfbot":True,
    "blacklist":{},
    "autoCancel": {
        "members": 1,
        "on": True
    },
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":False,
    "Js":True,
    "protect":True,
    "Kick":True,
    "Cancel":True,
    "Link":True,
    "contact":False,
    "invite":False,
    'autoJoin':True,
    'autoAdd':False,
    'autoBlock':False,
    'Timeline':False,
    'autoLeave':False,
    'autoLeave1':False,
    "detectMention":False,
    "mentionKick":False,
    "welcomeOn":False,
    "stickerOn":False,
    "likeOn":True,
    "chatbot": True,
    "tagall": "halo",
    "kikuk": "cubit",
    "cekUnsend": False,
    "limitinvite": False,
    "limitkick": False,
    "limitcancel": False,
    "AddstickerWelcome":{
        "sid": "",
        "spkg": "",
        "status":False
    },
    "AddstickerLeave":{
        "sid": "",
        "spkg": "",
        "status":False
    },
    "AddstickerSider":{
        "sid": "",
        "spkg": "",
        "status":False
    },
    "AddstickerTag":{
        "sid": "",
        "spkg": "",
        "status":False
    },
    "Addsticker":{
            "name": "",
            "status":False
            },
    "stk":{},
    "selfbot":True,
    "Images":{},
    "Img":{},
    "Addimage":{
            "name": "",
            "status":False
            },
    "Addaudio":{
            "name": "",
            "status":False
            },
    #"Addvideo":{
            #"name": "",
            #"status":False
            #},
    "unsend":False,
    "mention":"ʜᴇᴍ ɴɢɪɴᴛɪᴘ ʙᴇʙ",
    "Respontag":"\nTag terus ampe crot",   
    "welcome":"sᴇᴍᴏɢᴀ ʙᴇᴛah",
    "Leave":"sᴇʟᴀᴍᴀᴛ tinggal",
    "comment":"╭───────────────\n│╭──────────────\n│├• ᴛᴇʀɪᴍᴀᴋᴀsɪʜ\n│├•  elank bot \n│╰──────────────\n├──•〔 ᴏ ᴘ ᴇ ɴ ʀ ᴇ ɴ ᴛ ᴀ ʟ 〕\n│╭──────────────\n│├─•  sᴇʟғʙᴏᴛ :\n││( 𝟏 )• ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n││( 𝟐 )• ɴᴏ ᴛᴇᴍᴘʟᴀᴛᴇ\n│├─•  ᴘʀᴏᴛᴇᴄᴛ / ᴡᴀʀ :\n││( 𝟏 )• 𝟑 ᴀssɪsᴛ\n││( 𝟐 )• 𝟓 ᴀssɪsᴛ\n││( 𝟑 )• 𝟕 ᴀssɪsᴛ\n││( 𝟒 )• ᴄʟɪᴇɴᴛ ᴘʀᴏᴛᴇᴄᴛ\n│╰──────────────\n├──•〔 sᴇʟʟ   ᴛʜᴇ   sᴄʀɪᴘᴛ 〕\n│╭──────────────\n││( 𝟏 )• ʜᴇʟᴘᴇʀs\n││( 𝟐 )• sʙ ᴡᴀʀ\n││( 𝟑 )• sʙ ᴘʀᴏᴛᴇᴄᴛ\n││( 𝟒 )• ᴄʟ/ᴄʟɪᴇɴᴛ\n││( 𝟓 )• sʙ ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n│╰──────────────\n│ ན ᴄʀ : line://ti/p/~elanksbots.py\n│ ན ᴄʀ : line://ti/p/~pembantairoom112\n╰───────────────",
    "message":"╭───────────────\n│╭──────────────\n│├• ᴛʜᴀɴᴋᴢ ғᴏʀᴅ ᴀᴅᴅ ᴍᴇ\n│├• elank bot \n│╰──────────────\n├──•〔 ᴏ ᴘ ᴇ ɴ ʀ ᴇ ɴ ᴛ ᴀ ʟ 〕\n│╭──────────────\n│├─•  sᴇʟғʙᴏᴛ :\n││( 𝟏 )• ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n││( 𝟐 )• ɴᴏ ᴛᴇᴍᴘʟᴀᴛᴇ\n│├─•  ᴘʀᴏᴛᴇᴄᴛ / ᴡᴀʀ :\n││( 𝟏 )• 𝟑 ᴀssɪsᴛ\n││( 𝟐 )• 𝟓 ᴀssɪsᴛ\n││( 𝟑 )• 𝟕 ᴀssɪsᴛ\n││( 𝟒 )• ᴄʟɪᴇɴᴛ ᴘʀᴏᴛᴇᴄᴛ\n│╰──────────────\n├──•〔 sᴇʟʟ   ᴛʜᴇ   sᴄʀɪᴘᴛ 〕\n│╭──────────────\n││( 𝟏 )• ʜᴇʟᴘᴇʀs\n││( 𝟐 )• sʙ ᴡᴀʀ\n││( 𝟑 )• sʙ ᴘʀᴏᴛᴇᴄᴛ\n││( 𝟒 )• ᴄʟ/ᴄʟɪᴇɴᴛ\n││( 𝟓 )• sʙ ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n│╰──────────────\n│ ན ᴄʀ : line://ti/p/~elanksbots.py\n│ ན ᴄʀ : line://ti/p/~pembantairoom112\n╰───────────────",
}

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}
try:
    with open("Log_data.json","r",encoding="utf_8_sig") as f:
        msg_dict = json.loads(f.read())
except:
    print("Couldn't read Log data")
#============================================
elanksProfile = elanks.getProfile()
myProfile["displayName"] = elanksProfile.displayName
myProfile["statusMessage"] = elanksProfile.statusMessage
myProfile["pictureStatus"] = elanksProfile.pictureStatus
#============================================
contact = elanks.getProfile()
backup = elanks.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus
#============================================
imagesOpen = codecs.open("image.json","r","utf-8")
images = json.load(imagesOpen)
#videosOpen = codecs.open("video.json","r","utf-8")
#videos = json.load(videosOpen)
stickersOpen = codecs.open("sticker.json","r","utf-8")
stickers = json.load(stickersOpen)
audiosOpen = codecs.open("audio.json","r","utf-8")
audios = json.load(audiosOpen)
mulai = time.time()
#============================================
msg_dict = {}
msg_dict1 = {}
#============================================
tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
#============================================
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
#===========================
def autolike():
    for zx in range(0,500):
      hasil = elanks.activity(limit=500)
      if hasil['result']['posts'][zx]['postInfo']['liked'] == True:
        try:
          elanks.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          elanks.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postid'],wait["comment"])
          print ("✪[]► Like Success")
        except:
          pass
      else:
          print ("Already Liked")
#==============================
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')
#==============================
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > timedelta(1):
            if "path" in msg_dict[data]:
                elanks.deleteFile(msg_dict[data]["path"])
            del msg_dict[data]
#==============================
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]
#==============================
def logError(text):
    elanks.log("[ ERROR ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("logError.txt","a") as error:
        error.write("\n[ {} ] {}".format(str(time), text))
#==============================
def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"
#==============================
def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items
#==============================
def downloadObjectMsg(self, messageId, returnAs='path', saveAs=''):
    if saveAs == '':
        saveAs = self.genTempFile('path')
    if returnAs not in ['path','bool','bin']:
        raise Exception('Invalid returnAs value')
    params = {'oid': messageId}
    url = self.server.urlEncode(self.server.LINE_OBS_DOMAIN, '/talk/m/download.nhn', params)
    r = self.server.getContent(url)
    if r.status_code == 200:
        self.saveFile(saveAs, r.raw)
        if returnAs == 'path':
            return saveAs
        elif returnAs == 'bool':
            return True
        elif returnAs == 'bin':
            return r.raw
    else:
        raise Exception('Download object failure.')
#==============================
def downloadImageWithURL (mid):
    contact = elanks.getContact(mid)
    if contact.videoProfile == None:
        elanks.elanksoneContactProfile(mid)
    else:
        profile = elanks.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        elanks.updateProfile(profile)
        pict = elanks.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = elanks.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = elanks.getProfileDetail(mid)['result']['objectId']
    elanks.updateProfileCoverById(coverId)
#==============================
def removeMessage(elanks, lastMessageId):
    return elanks.talk.removeAllMessage(0, lastMessageId)

def getRecentMessagesV2(self, chatId, count=50):
    return elanks.talk.getRecentMessagesV2(chatId,count)
#==============================
def restartBot():
    python = sys.executable
    os.exeelanks(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def sendImage(to, path, name="image"):
    try:
        if setttings["server"] == "VPS":
            elanks.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)

def changeProfileVideo(to):
    if settings['changevp']['picture'] == True:
        return sendFooterAbhel(to, "Foto tidak ditemukan")
    elif settings['changevp']['video'] == True:
        return sendFooterAbhel(to, "Video tidak ditemukan")
    else:
        path = settings['changevp']['video']
        files = {'file': open(path, 'rb')}
        obs_params = elanks.genOBSParams({'oid': elanks.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = elanks.server.postContent('{}/talk/vp/upload.nhn'.format(str(elanks.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return sendFooterAbhel(to, "Gagal update profile")
        path_p = settings['changevp']['picture']
        settings['changevp']['status'] = True
        elanks.updateProfilePicture(path_p, 'vp')

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = elanks.genOBSParams({'oid': elanksMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = elanks.server.postContent('{}/talk/vp/upload.nhn'.format(str(elanks.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        elanks.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))

def restoreProfile():
    profile = elanks.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        elanks.updateProfileAttribute(8, profile.pictureStatus)
        elanks.updateProfile(profile)
    else:
        elanks.updateProfile(profile)
        pict = elanks.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = elanks.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    elanks.updateProfileCoverById(coverId)

def changeProfileVideo(to):
    if Setmain['changeProfileVideo']['picture'] == None:
        return elanks.sendMessage(to, "Foto tidak ditemukan")
    elif Setmain['changeProfileVideo']['video'] == None:
        return elanks.sendMessage(to, "Video tidak ditemukan")
    else:
        path = Setmaim['changeProfileVideo']['video']
        files = {'file': open(path, 'rb')}
        obs_params = elanks.genOBSParams({'oid': elanks.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = elanks.server.postContent('{}/talk/vp/upload.nhn'.format(str(elanks.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return elanks.sendMessage(to, "Gagal update profile")
        path_p = Setmain['changeProfileVideo']['picture']
        Setmain['changeProfileVideo']['status'] = False
        elanks.updateProfilePicture(path_p, 'vp')

def changetest(vids, picts):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = elanks.genOBSParams({'oid': elanksMID, 'type': 'video', 'ver': '2.0', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = elanks.server.postContent('{}/talk/vp/upload.nhn'.format(str(elanks.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return elanks.sendMessage(to, "Error")
        picture = picts
        elanks.updateProfilePicture(picture, 'vp')
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
           
def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = elanks.getGroup(to)
        textx = "「 Mentions Members 」\n\n1. "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "{}. ".format(str(no))
            else:
                textx += "\n「 Mentions {} Member 」".format(str(len(mid)))
        elanks.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        elanks.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "Haii ".format(str(mid))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+settings["mention"]#+"\n "+str(ginfo.name)+"\nelanks__bots"
            if no < len(mid):
                no += 1
                textx += " " % (num)
                num=(num+1)
            else:
                try:
                    no += "╚══[ {} ]".format(str(elanks.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        elanks.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        elanks.sendMessage(to, "[ INFO ] Error :\n" + str(error))
          
def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "Eh ada ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(elanks.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        elanks.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        elanks.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "Hallo ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = elanks.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]+" Di "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(elanks.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        elanks.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        elanks.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "Selamat tinggal ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = elanks.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["leave"]
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(elanks.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        elanks.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        elanks.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        elanks.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        elanks.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendImage(to, path, name="image"):
    try:
        if setttings["server"] == "VPS":
            elanks.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)
            
def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain['keyCommand']):
        cmd = pesan.replace(Setmain['keyCommand'],"")
    else:
        cmd = "command"
    return cmd
    
def help():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "╭─────────\n"+\
                  "│╭────────  \n "+ \
                  "│├• 〔  ᴍᴇɴᴜ 1 〕 \n" + \
                  "│╰────────\n" + \
                  "│╭────────\n" + \
                  "││ " + key + " me\n" + \
                  "││ " + key + " menu1\n" + \
                  "││ " + key + " menu2\n" + \
                  "││ " + key + " mybot\n" + \
                  "││ " + key + " mycrot\n" + \
                  "││ " + key + " #bantai\n" + \
                  "││ " + key + " #hobah\n" + \
                  "││ " + key + " jiran <no>\n" + \
                  "│╰────────\n" +\
                  "│ ├•  by : elank_team \n" +\
                  "╰─────────"
    return helpMessage
    
def commandMenu1():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage1 = "╭─────────\n"+\
                  "│╭────────  \n "+ \
                  "│├• 〔  ᴍᴇɴᴜ 2 〕 \n" + \
                  "│╰────────\n" + \
                  "│╭────────\n" + \
                  "││ " + key + " respon on/off\n" + \
                  "││ " + key + " autojoin on/off \n" + \
                  "││ " + key + " autoblock on/off \n" + \
                  "││ " + key + " autoriject on/off \n" + \
                  "││ " + key + " autoadd on/off \n" + \
                  "││ " + key + " autoreed on/off \n" + \
                  "││ " + key + " unsend on/off \n" + \
                  "││ " + key + " jointicket on/off \n" + \
                  "││ " + key + " chatbot on/off \n" + \
                  "││ " + key + " sticker on/off \n" + \
                  "││ " + key + " autolike on/off \n" + \
                  "││ " + key + " timeline on/off \n" + \
                  "││ " + key + " contact on/off \n" + \
                  "││ " + key + " invite on/off \n" + \
                  "││ " + key + " time on/off \n" + \
                  "│╰────────\n" +\
                  "│ ├•  by : elank_team \n" +\
                  "╰─────────"
    return helpMessage1
    
def commandMenu2():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage2 = "╭─────────\n"+\
                  "│╭────────  \n "+ \
                  "│├• 〔  ᴍᴇɴᴜ 3 〕 \n" + \
                  "│╰────────\n" + \
                  "│╭────────\n" + \
                  "││ " + key + " set respon: <kata> \n" + \
                  "││ " + key + " set welcome: <kata>  \n" + \
                  "││ " + key + " set leave: <kata>  \n" + \
                  "││ " + key + " set tag: <kata> \n" + \
                  "││ " + key + " set ciluk: <kata>  \n" + \
                  "│╰─────────── \n" + \
                  "│╭───────────  \n" + \
                  "││ " + key + " reboot \n" + \
                  "││ " + key + " hapus mantan \n" + \
                  "││ " + key + " ciluk ba\n" + \
                  "││ " + key + " colok ni \n" + \
                  "││ " + key + " blacklist \n" + \
                  "││ " + key + " ampuni \n" + \
                  "││ " + key + " maafin \n" + \
                  "││ " + key + " byeme \n" + \
                  "││ " + key + " blc \n" + \
                  "││ " + key + " ping \n" + \
                  "││ " + key + " open \n" + \
                  "││ " + key + " elanksose \n" + \
                  "││ " + key + " link \n" + \
                  "││ " + key + " glist \n" + \
                  "│╰────────\n" +\
                  "│ ├•  by : elank_team \n" +\
                  "╰─────────"
    return helpMessage2

#message.createdTime -> 00:00:00
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log1():
    ndt = datetime.now()
    for data in msg_dict1:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict1[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict1[msg_id]

def atend1():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict1, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

#message.createdTime -> 00:00:00
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")
    
def lockqr(grup):
    G = elanks.getGroup(grup)
    G.preventedJoinByTicket = True
    try:
        elanks.updateGroup(G)
    except:
        pass

def lockqr1(grup):
    G = random.choice(ABC).getGroup(grup)
    G.preventedJoinByTicket = True
    try:
        elanks.updateGroup(G)
    except:
        pass

def black(target):
    if target not in wait["blacklist"]:
        wait["blacklist"][target] = True

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoBlock"] == False:
                elanks.blockContact(op.param1)
                elanks.sendMessage(op.param1,"╭───────────────\n│╭──────────────\n│├• ᴛʜᴀɴᴋᴢ ғᴏʀᴅ ᴀᴅᴅ ᴍᴇ\n│├• sᴀмuᴅʀᴀ \n│╰──────────────\n├──•〔 ᴏ ᴘ ᴇ ɴ ʀ ᴇ ɴ ᴛ ᴀ ʟ 〕\n│╭──────────────\n│├─•  sᴇʟғʙᴏᴛ :\n││( 𝟏 )• ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n││( 𝟐 )• ɴᴏ ᴛᴇᴍᴘʟᴀᴛᴇ\n│├─•  ᴘʀᴏᴛᴇᴄᴛ / ᴡᴀʀ :\n││( 𝟏 )• 𝟑 ᴀssɪsᴛ\n││( 𝟐 )• 𝟓 ᴀssɪsᴛ\n││( 𝟑 )• 𝟕 ᴀssɪsᴛ\n││( 𝟒 )• ᴄʟɪᴇɴᴛ ᴘʀᴏᴛᴇᴄᴛ\n│╰──────────────\n├──•〔 sᴇʟʟ   ᴛʜᴇ   sᴄʀɪᴘᴛ 〕\n│╭──────────────\n││( 𝟏 )• ʜᴇʟᴘᴇʀs\n││( 𝟐 )• sʙ ᴡᴀʀ\n││( 𝟑 )• sʙ ᴘʀᴏᴛᴇᴄᴛ\n││( 𝟒 )• ᴄʟ/ᴄʟɪᴇɴᴛ\n││( 𝟓 )• sʙ ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n│╰──────────────\n│ ན ᴄʀ : line://ti/p/~elanksbots.py\n│ ན ᴄʀ : line://ti/p/~pembantairoom112\n╰───────────────")

        if op.type == 11 or op.type == 122:
            if op.param3 == '1':
                if op.param1 in wait['pname']:
                    wait["blacklist"][op.param2] = True
                    try:
                        G = elanks.getGroup(op.param1)
                        elanks.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            G = elanks.getGroup(op.param1)
                            elanks.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            pass
                    G.name = wait['pro_name'][op.param1]
                    try:
                        elanks.updateGroup(G)
                    except:
                        try:
                            elanks.updateGroup(G)
                        except:
                            pass
                    if op.param2 in Bots:
                        pass
                    elif op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        pass
                    else:
                        try:
                            elanks.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                elanks.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                pass

            if op.param3 == '2':
                if op.param1 in wait['lockicon']:
                   try:
                       G = elanks.getGroup(op.param1)
                   except:
                       pass
                   G.pictureStatus = wait['save_icon'][op.param1]
                   try:
                       elanks.updateGroup(G)
                   except:
                        pass
                   if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                       try:
                           elanks.kickoutFromGroup(op.param1,[op.param2])
                           wait["blacklist"][op.param2] = True
                       except:pass
            print("PROTECT ICON GROUP")

        if op.type == 17 or op.type == 130:
          if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
            if op.param2 in wait["blacklist"]:
                elanks.kickoutFromGroup(op.param1,[op.param2])
        if op.type == 17 or op.type == 130:
          if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
            if op.param2 in wait["blacklist"]:
                elanks1.kickoutFromGroup(op.param1,[op.param2])
#──────────────────────
#BLACKLIST__NGINVITE
        if op.type == 13 or op.type == 124:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        group = elanks.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for xx in gMembMids:
                            if xx in op.param3:
                                elanks.cancelGroupInvitation(op.param1,[xx])
                                elanks.kickoutFromGroup(op.param1,[op.param2])
                                geBlack(xx)
                        gMemb = [contact.mid for contact in group.members]
                        for xx in gMemb:
                            if xx in wait["blacklist"]:
                                elanks.kickoutFromGroup(op.param1,[xx])
                    except:
                        try:
                            group = random.choice(Teamelanks).getGroup(op.param1)
                            gMembMids = [contact.mid for contact in group.invitee]
                            for xx in gMembMids:
                                if xx in op.param3:
                                    random.choice(Teamelanks).cancelGroupInvitation(op.param1,[xx])
                                    random.choice(Teamelanks).kickoutFromGroup(op.param1,[op.param2])
                                    geBlack(xx)
                            gMemb = [contact.mid for contact in group.members]
                            for xx in gMemb:
                                if xx in wait["blacklist"]:
                                    random.choice(Teamelanks).kickoutFromGroup(op.param1,[xx])
                        except:
                            pass
                            
#INVITE__BLACKLIST
        if op.type == 13 or op.type == 124:
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        group = elanks.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for xx in gMembMids:
                            if xx in op.param3:
                                elanks.cancelGroupInvitation(op.param1,[xx])
                                elanks.kickoutFromGroup(op.param1,[op.param2])
                                geBlack(op.param2)
                        gMemb = [contact.mid for contact in group.members]
                        for xx in gMemb:
                            if xx in wait["blacklist"]:
                                elanks.kickoutFromGroup(op.param1,[xx])
                    except:
                        try:
                            group = random.choice(Teamelanks).getGroup(op.param1)
                            gMembMids = [contact.mid for contact in group.invitee]
                            for xx in gMembMids:
                                if xx in op.param3:
                                    random.choice(Teamelanks).cancelGroupInvitation(op.param1,[xx])
                                    random.choice(Teamelanks).kickoutFromGroup(op.param1,[op.param2])
                                    geBlack(op.param2)
                            gMemb = [contact.mid for contact in group.members]
                            for xx in gMemb:
                                if xx in wait["blacklist"]:
                                    random.choice(Teamelanks).kickoutFromGroup(op.param1,[xx])
                        except:
                            pass

        if op.type == 55 or op.type == 126:
            if op.param2 in wait["blacklist"]:
               try:
                   elanks.kickoutFromGroup(op.param1,[op.param2])
                   time.sleep(0.0001)
                   sendTextTemplate1(op.param1,"sorry your blacklist")
               except:
                   pass

        if op.type == 32 or op.type == 126:
            if op.param3 in Amid:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                     wait["blacklist"][op.param2] = True
                     try:
                         elanks.kickoutFromGroup(op.param1,[op.param2])
                         elanks.inviteIntoGroup(op.param1,[Amid])
                     except:
                         pass

#======ANTI BYPASS=========#
        if op.type == 32 or op.type == 126:
           if wait["BACKUP CANCELL"] == True:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                 wait["blacklist"][op.param2] = True
                 try:
                     if op.param3 not in wait["blacklist"]:
                         elanks.kickoutFromGroup(op.param1,[op.param2])
                 except:
                     pass

        if op.type == 19 or op.type == 133:
           if wait["BACKUP KICK"] == True:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                 wait["blacklist"][op.param2] = True
                 try:
                     if op.param3 not in wait["blacklist"]:
                         elanks1.acceptGroupInvitation(op.param1)
                         elanks1.kickoutFromGroup(op.param1,[op.param2])
                         elanks1.inviteIntoGroup(op.param1,[mid])
                         elanks.acceptGroupInvitation(op.param1)
                         elanks1.leaveGroup(op.param1)
                         elanks.inviteIntoGroup(op.param1,[Amid])
                 except:
                     try:
                         if op.param3 not in wait["blacklist"]:
                             elanks.kickoutFromGroup(op.param1,[op.param2])
                     except:
                         pass
                         
#======ANTI JS=========#
        if op.type == 19 or op.type == 133:
            if mid in op.param3:
                if op.param2 in elanksBOTS:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        elanks1.acceptGroupInvitation(op.param1)
                        elanks1.kickoutFromGroup(op.param1,[op.param2])
                        elanks1.findAndAddContactsByMid(op.param3)
                        elanks1.inviteIntoGroup(op.param1,[mid])
                        elanks.acceptGroupInvitation(op.param1)
                        elanks1.leaveGroup(op.param1)
                        elanks.inviteIntoGroup(op.param1,[Amid])
                    except:
                        pass            
            if Amid in op.param3:
                if op.param2 in Team:
                    pass
                else:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        wait["blacklist"][op.param2] = True
                    try:
                        elanks.kickoutFromGroup(op.param1,[op.param2])
                        elanks.inviteIntoGroup(op.param1,[Amid])
                        group = elanks.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.members]
                        for _mid in gMembMids:
                          if _mid in wait["blacklist"]:
                            elanks.kickoutFromGroup(op.param1,[_mid])
                    except:
                        pass
                return
#======LEAVE ANTI JS====#                                             
        if op.type == 15 or op.type == 128:
            if op.param3 in Amid:
                group = elanks.getGroup(op.param1)
                Anakku = [Amid]
                for x in Anakku:
                    try:
                        Otong = [elanks]
                        Otong.inviteIntoGroup(op.param1,[x])
                    except:
                      pass

        if op.type == 19 or op.type == 133:
            if op.param3 in admin:
                if op.param2 not in elanksBOTS and op.param2 not in admin:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            elanks.kickoutFromGroup(op.param1,[op.param2])
                            elanks.findAndAddContactsByMid(jack)
                            elanks.inviteIntoGroup(op.param1,[jack])
                        except:
                            pass
            
#==================[PROTECT QR]===================        
        if op.type == 25 or op.type == 26:
          if wait['undang'] == True:
            msg = op.message
            user = msg._from
            kirim = msg.to    	
            if msg.contentType == 13:
                #if wait["Admin"]:
                    _name = msg.contentMetadata["displayName"]
                    invite = msg.contentMetadata["mid"]
                    groups = elanks.getGroup(kirim)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            elanks.sendMessage(msg.to, _name + " Sudah hadir dalam grup")
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                elanks.findAndAddContactsByMid(target)
                                elanks.inviteIntoGroup(kirim,[target])
                                elanks.elanks(msg.to,"undang " + _name + "\nSUCCESS..")
                                wait['undang'] = False
                                break
                            except:             
                                 elanks.sendMessage(msg.to, 'Sukse Bos')
                                 wait['undang'] = False
                                 break

        if op.type == 11:
            if op.param1 in proLink:
                try:
                    if elanks.getGroup(op.param1).preventedJoinByTicket == True:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            elanks.reissueGroupTicket(op.param1)
                            X = elanks.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            elanks.updateGroup(X)
                            elanks.kickoutFromGroup(op.param1,[op.param2])
                            elanks.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                except:
                    pass
#==================[BLACKLIST QR]=================== 
        if op.type == 11:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    t = Thread(target=attck, args=(op.param1, op.param2))
                    t.start()
                    t1 = Thread(target=lockqr, args=(op.param1,))
                    t1.start()
                    t2 = Thread(target=lockqr1, args=(op.param1,))
                    t2.start()
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    t3 = Thread(target=attck, args=(op.param1, op.param2))
                    t3.start()
                    t4 = Thread(target=lockqr, args=(op.param1,))
                    t4.start() 
                    t5 = Thread(target=lockqr1, args=(op.param1,))
                    t5.start()
            if op.param1 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    t6 = Thread(target=attck, args=(op.param1, op.param2))
                    t6.start()
                    t7 = Thread(target=lockqr, args=(op.param1,))
                    t7.start() 
                    t8 = Thread(target=lockqr1, args=(op.param1,))
                    t8.start()  
#==================[AUTO JOIN CANCELL]===================                                



        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        elanks.acceptGroupInvitation(op.param1)
                    else:
                        elanks.acceptGroupInvitation(op.param1)

            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots:
                    t9 = Thread(target=attck, args=(op.param1, op.param2))
                    t9.start()
                    t10 = Thread(target=canelanks, args=(op.param1, op.param3))
                    t10.start()
                    t11 = Thread(target=black, args=(op.param2,))
                    t11.start()
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots:
                    t12 = Thread(target=attck, args=(op.param1, op.param2))
                    t12.start()
                    t13 = Thread(target=canelanks, args=(op.param1, op.param3))
                    t13.start()
                    t14 = Thread(target=black, args=(op.param2,))
                    t14.start()                  #  t14.start()
#==================[AUTO LEAVE]===================                                
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        elanks.acceptGroupInvitation(op.param1)
                        ginfo = elanks.getGroup(op.param1)
                        elanks.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        elanks.leaveGroup(op.param1)
                    else:
                        elanks.acceptGroupInvitation(op.param1)
                        ginfo = elanks.getGroup(op.param1)
                        #elanks.sendMessage(op.param1," " + str(ginfo.name))
#==================[PROTECT INVITE]===================                                
        if op.type == 13:
            if op.param1 in proInvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        group = elanks.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            elanks.cancelGroupInvitation(op.param1,[op.param3])
                            elanks.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
#==================[WELCOME & LEAVE]===================                                
        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = elanks.getGroup(op.param1)
                contact = elanks.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                elanks.sendImageWithURL(op.param1, image)

        if op.type == 15:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = elanks.getGroup(op.param1)
                contact = elanks.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                leaveMembers(op.param1, [op.param2])
                elanks.sendImageWithURL(op.param1, image)
#==================[BLACKLIST JOIN PURGE]===================    
        if op.type == 17: #JOIN
            if op.param2 in wait["blacklist"]:
                t15 = Thread(target=attck, args=(op.param1, op.param2))
                t15.start()
                t16 = Thread(target=attck, args=(op.param1, op.param2))
                t16.start()
            if op.param1 in wait["blacklist"]:
                t17 = Thread(target=attck, args=(op.param1, op.param2))
                t17.start()
                t18 = Thread(target=attck, args=(op.param1, op.param2))
                t18.start()
#==================[PROTECT JOIN]===================                                                            
        if op.type == 17:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                        	random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            if op.param3 not in wait["blacklist"]:
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                if op.param3 not in wait["blacklist"]:
                                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    if op.param3 not in wait["blacklist"]:
                                        random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    pass
                return
#=============================================                                                            
        if op.type == 0:
            return
        if op.type == 5:
              if wait["autoAdd"] == True:
                  elanks.findAndAddContactsByMid(op.param1)
                  sendMention(op.param1, op.param1, "Hai broo ", ", ")
                  elanks.sendMessage(op.param1, wait["message"])

        if op.type == 5:
            print ("[ 5 ] NOTIFIED AUTO BLOCK CONTACT")
            if wait["autoBlock"] == False:
                elanks.blockContact(op.param1)
                elanks.sendMessage(op.param1,"╭───────────────\n│╭──────────────\n│├• ᴛᴇʀɪᴍᴀᴋᴀsɪʜ\n│├• sᴀмuᴅʀᴀ\n│╰──────────────\n├──•〔 ᴏ ᴘ ᴇ ɴ ʀ ᴇ ɴ ᴛ ᴀ ʟ 〕\n│╭──────────────\n│├─•  sᴇʟғʙᴏᴛ :\n││( 𝟏 )• ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n││( 𝟐 )• ɴᴏ ᴛᴇᴍᴘʟᴀᴛᴇ\n│├─•  ᴘʀᴏᴛᴇᴄᴛ / ᴡᴀʀ :\n││( 𝟏 )• 𝟑 ᴀssɪsᴛ\n││( 𝟐 )• 𝟓 ᴀssɪsᴛ\n││( 𝟑 )• 𝟕 ᴀssɪsᴛ\n││( ?? )• ᴄʟɪᴇɴᴛ ᴘʀᴏᴛᴇᴄᴛ\n│╰──────────────\n├──•〔 sᴇʟʟ   ᴛʜᴇ   sᴄʀɪᴘᴛ 〕\n│╭──────────────\n││( 𝟏 )• ʜᴇʟᴘᴇʀs\n││( 𝟐 )• sʙ ᴡᴀʀ\n││( 𝟑 )• sʙ ᴘʀᴏᴛᴇᴄᴛ\n││( 𝟒 )• ᴄʟ/ᴄʟɪᴇɴᴛ\n││( 𝟓 )• sʙ ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n│╰──────────────\n│ ན ᴄʀ : line://ti/p/~elanksbots.py\n│ ན ᴄʀ : line://ti/p/~elanksbots.py\n╰───────────────")

        if op.type == 65:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = elanks.getGroup(at)
                                ryan = elanks.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "╭─「 Gambar Dihapus 」\n│ Pengirim : "
                                ret_ = "│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                elanks.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                elanks.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = elanks.getGroup(at)
                                ryan = elanks.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "╭─「 Pesan Dihapus 」\n"
                                ret_ += "│ Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n│ Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                ret_ += "\n╰───────────"
                                elanks.sendMessage(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = elanks.getGroup(at)
                                ryan = elanks.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "╭─「 Sticker Dihapus 」\n"
                                ret_ += "│ Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                ret_ += "\n╰───────────"
                                elanks.sendMessage(at, str(ret_))
                                elanks.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
#=================[BACKUPS elanks BOTS]=================    
        if op.type == 19:
            if op.param3 in owner:
                    if op.param2 in owner:
                        pass
                    if op.param2 in admin:
                        pass
                    if op.param2 in staff:
                        pass
                    if op.param2 in Bots:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        try:
                            elanks.acceptGroupInvitation(op.param1)
                            random.choice(KAC).inviteIntoGroup(op.param1,[mid])
                        except:
                            pass
                            
            if op.param3 in admin:
                    if op.param2 not in owner:
                        pass
                    if op.param2 not in admin:
                        pass
                    if op.param2 not in staff:
                        pass
                    if op.param2 not in Bots:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        try:
                            elanks.acceptGroupInvitation(op.param1)
                            random.choice(KAC).inviteIntoGroup(op.param1,[mid])
                        except:
                            pass       
                                    
        if op.type == 19:
            if mid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    t19 = Thread(target=attck, args=(op.param1, op.param2))
                    t19.start()
                    t20 = Thread(target=black, args=(op.param2,))
                    t20.start()
                    t21 = Thread(target=backp, args=(op.param1, op.param3))
                    t21.start()
                return
            if Amid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    t22 = Thread(target=attck, args=(op.param1, op.param2))
                    t22.start()
                    t23 = Thread(target=black, args=(op.param2,))
                    t23.start()
                    t24 = Thread(target=backp, args=(op.param1, op.param3))
                    t24.start()
                return
#========================[BACKUP OWNER ADMIN & STAFF]=====================    

        if op.type == 19:
            if op.param3 in owner:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            elanks.kickoutFromGroup(op.param1,[op.param2])
                            elanks.findAndAddContactsByMid(jack)
                            elanks.inviteIntoGroup(op.param1,[jack])
                        except:
                            pass
            if op.param3 in admin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            elanks.kickoutFromGroup(op.param1,[op.param2])
                            elanks.findAndAddContactsByMid(jack)
                            elanks.inviteIntoGroup(op.param1,[jack])
                        except:
                            pass

            if op.param3 in staff:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            elanks.kickoutFromGroup(op.param1,[op.param2])
                            elanks.findAndAddContactsByMid(jack)
                            elanks.inviteIntoGroup(op.param1,[jack])
                        except:
                            pass
#========================[PROTECT KICK]=====================                                                            
        if op.type == 19:
            if op.param1 in proKick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            elanks.kickoutFromGroup(op.param1,[op.param2])
                            elanks.findAndAddContactsByMid(jack)
                            sdmudra.inviteIntoGroup(op.param1,[jack])
                        except:
                            pass

        if op.type == 19:
            if op.param1 in wait["Kick"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(ABC).findAndAddContactsByMid(jack)
                            random.choice(ABC).inviteIntoGroup(op.param1,[jack])
                        except:
                            pass

        if op.type == 32:
            if op.param1 in wait["Cancel"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(ABC).inviteIntoGroup(msg.to, [mid])
                    except:
                        pass

        if op.type == 11:
            if op.param1 in wait["Link"] == True:
                try:
                    if elanks.getGroup(op.param1).preventedJoinByTicket == True:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            random.choice(ABC).reissueGroupTicket(op.param1)
                            X = random.choice(ABC).getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            randon.choice(ABC).updateGroup(X)
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                except:
                    pass

#======================[PROTECT CANCEL]=======================                                                            
        
        if op.type == 32:
            if op.param1 in protectcancel:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    pass
                else:
                    try:
                        if op.param3 not in wait["blacklist"]:
                            settings["blacklist"][op.param2] = True
                            if op.param3 not in settings["blacklist"]:
                                try:
                                    elanks.kickoutFromGroup(op.param1,[op.param2])
                                    elanks.findAndAddContactsByMid(op.param3)
                                    elanks.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    pass
                            else:pass
                        else:pass
                    except:
                        pass
#======================[BLACKLIST READ]=======================                                      
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                t52 = Thread(target=attck, args=(op.param1, op.param2))
                t52.start()      
            if op.param1 in wait["blacklist"]:
                t53 = Thread(target=attck, args=(op.param1, op.param2))
                t53.start()        
        
            if op.param1 in Setmain["ARreadPoint"]:
                if op.param2 in Setmain["ARreadMember"][op.param1]:
                    pass
                else:
                    Setmain["ARreadMember"][op.param1][op.param2] = True
            else:
                pass



        if op.type == 32 or op.type == 126:
            if wait["backup"] == True:
              if op.param3 in Bots:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            elanks.kickoutFromGroup(op.param1,[op.param2])
                            elanks.inviteIntoGroup(op.param1,[op.param3])
                    except:
                    	pass
                return

        if op.type == 19 or op.type == 32 or op.type == 133 or op.type == 126:
            if mid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in creator:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        elanks.acceptGroupInvitation(op.param1)
                        elanks.inviteIntoGroup(op.param1,[op.param3])
                        elanks.kickoutFromGroup(op.param1,[op.param2])
                    except:
                    	pass
                return

        if op.type == 19 or op.type == 32 or op.type == 133 or op.type == 126:
            if op.param3 in creator:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                elanks.findAndAddContactsByMid(op.param3)
                elanks.inviteIntoGroup(op.param1,[op.param3])
                elanks.kickoutFromGroup(op.param1,[op.param2])
                wait["blacklist"][op.param2] = True

            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = elanks.getContact(op.param2).displayName
                    Np = elanks.getContact(op.param2).pictureStatus
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        #elanks.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net/" + Np)
                        sid = str(wait["AddstickerSider"]["sid"])
                        spkg = str(wait["AddstickerSider"]["spkg"])
                        elanks.sendSticker(op.param1, spkg, sid)

        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                          except:
                              random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                if msg._from not in Bots:
                 if wait["detectMention"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']                   
                   for mention in mentionees:
                        if mention ['M'] in admin:
                           contact = elanks.getContact(msg._from)
                           anu = contact.displayName
                           elanks.sendMessage(msg.to, "."+anu+"\n"+wait["Respontag"])
                           sid = str(wait["AddstickerTag"]["sid"])
                           spkg = str(wait["AddstickerTag"]["spkg"])
                           elanks.sendSticker(msg.to, spkg, sid)
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                if msg._from not in Bots:
                 if wait["mentionKick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in admin:
                           elanks.sendMessage(msg.to, "Jangan tag saya ogeb")
                           elanks.kickoutFromGroup(msg.to, [msg._from])
                           break
               if msg.contentType == 7:
                 if wait["stickerOn"] == True:
                    msg.contentType = 0
                    elanks.sendMessage(msg.to,"╭─「 Cek ID Sticker 」\n├↘ STKID : " + msg.contentMetadata["STKID"] + "\n├↘ STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n├↘ STKVER : " + msg.contentMetadata["STKVER"]+ "\n├↘\n╰─「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    elanks.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = elanks.getContact(msg.contentMetadata["mid"])
                        path = elanks.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        elanks.sendMessage(msg.to,"╭─「 Contact Info 」\n├↘ Nama : " + msg.contentMetadata["displayName"] + "\n├↘ MID : " + msg.contentMetadata["mid"] + "\n├↘ Status Msg : " + contact.statusMessage + "\n├↘ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        elanks.sendImageWithURL(msg.to, image)	
                        
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            stickername = str(text)
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 16:
                    if wait["Timeline"] == True:
                            ret_ = "「 Detail Postingan 」"
                            if msg.contentMetadata["serviceType"] == "GB":
                                contact = elanks.getContact(sender)
                                auth = "\n• Penulis : {}".format(str(contact.displayName))
                            else:
                                auth = "\n• Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
                            ret_ += auth
                            if "stickerId" in msg.contentMetadata:
                                stck = "\n• Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                ret_ += stck
                            if "mediaOid" in msg.contentMetadata:
                                object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                if msg.contentMetadata["mediaType"] == "V":
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                        murl = "\n• Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                        murl = "\n• Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                    ret_ += murl
                                else:
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                ret_ += ourl
                            if "text" in msg.contentMetadata:
                                text = "\n• Tulisan : {}".format(str(msg.contentMetadata["text"]))
                                purl = "\n• Post URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                ret_ += purl
                                ret_ += text
                            elanks.sendMessage(to, str(ret_))
               if msg.contentType == 16:
                if wait["likeOn"] == True:
                    url = msg.contentMetadata["postEndUrl"]
                    daftarLike = [1001,1002,1003,1004,1005,1006]
                    likeType = random.choice(daftarLike)
                    elanks.like(url[25:58], url[66:], likeType=1006)
                    elanks.comment(url[25:58], url[66:], wait["comment"])      
                    
               if msg.contentType == 7:
                 if msg._from in creator or msg._from in owner or msg._from in admin:
                    if wait["AddstickerTag"]["status"] == True:
                        wait["AddstickerTag"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerTag"]["spkg"] = msg.contentMetadata['STKPKGID']
                        elanks.sendMessage(msg.to, "Succses merubah sticker respon 🎵")
                        wait["AddstickerTag"]["status"] = False     
               if msg.contentType == 7:
                 if msg._from in creator or msg._from in owner or msg._from in admin:
                    if wait["AddstickerSider"]["status"] == True:
                        wait["AddstickerSider"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerSider"]["spkg"] = msg.contentMetadata['STKPKGID']
                        elanks.sendMessage(msg.to, "sukses menambahkan sticker sider 🎵")
                        wait["AddstickerSider"]["status"] = False
               if msg.contentType == 7:
                 if msg._from in creator or msg._from in owner or msg._from in admin:
                    if wait["AddstickerWelcome"]["status"] == True:
                        wait["AddstickerWelcome"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerWelcome"]["spkg"] = msg.contentMetadata['STKPKGID']
                        elanks.sendMessage(msg.to, "Succses merubah sticker welccome 🎵")
                        wait["AddstickerWelcome"]["status"] = False     
               if msg.contentType == 7:
                 if msg._from in creator or msg._from in owner or msg._from in admin:
                    if wait["AddstickerLeave"]["status"] == True:
                        wait["AddstickerLeave"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerLeave"]["spkg"] = msg.contentMetadata['STKPKGID']
                        elanks.sendMessage(msg.to, "sukses menambahkan leave 🎵")
                        wait["AddstickerLeave"]["status"] = False                   
                       
               if msg.contentType == 0:
                    msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
               if msg.text:
                    if msg.text.lower().lstrip().rstrip() in wbanlist:
                        if msg.text not in elanksientMID:
                            try:
                                elanks.kickoutFromGroup(msg.to,[sender])
                            except Exception as e:
                                 print(e)
               if msg.contentType == 1:
                    path = elanks.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'Gambarnya dibawah',"data":path,"from":msg._from,"createdTime":msg.createdTime}
               if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n\n「 Sticker Info 」"
                   ret_ += "\n➪ Sticker ID : {}".format(stk_id)
                   ret_ += "\n➪ Sticker Version : {}".format(stk_ver)
                   ret_ += "\n➪ Sticker Package : {}".format(pkg_id)
                   ret_ += "\n➪ Sticker Url : line://shop/detail/{}".format(pkg_id)
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = elanks.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
               if msg.contentType == 7:
                if wait["stickerOn"] == True:
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    with requests.session() as s:
                        s.headers['user-agent'] = 'Mozilla/5.0'
                        r = s.get("https://store.line.me/stickershop/product/{}/id".format(urllib.parse.quote(pkg_id)))
                        soup = BeautifulSoup(r.content, 'html5lib')
                        data = soup.select("[elanksass~=mdBtn01Txt]")[0].text
                        if data == 'Lihat Produk Lain':
                            ret_ = "「 Sticker Info 」"
                            ret_ += "\n~STICKER ID : {}".format(stk_id)
                            ret_ += "\n~STICKER PACKAGES ID : {}".format(pkg_id)
                            ret_ += "\n~STICKER VERSION : {}".format(stk_ver)
                            ret_ += "\n~STICKER URL : line://shop/detail/{}".format(pkg_id)
                            elanks.sendMessage(msg.to, str(ret_))
                            query = int(stk_id)
                            if type(query) == int:
                               data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                               path = elanks.downloadFileURL(data)
                               elanks.sendImage(msg.to,path)
                        else:
                            ret_ = "「 Sticker Info 」"
                            ret_ += "\n~PRICE : "+soup.findAll('p', attrs={'elanksass':'mdCMN08Price'})[0].text
                            ret_ += "\n~AUTHOR : "+soup.select("a[href*=/stickershop/author]")[0].text
                            ret_ += "\n~STICKER ID : {}".format(str(stk_id))
                            ret_ += "\n~STICKER PACKAGES ID : {}".format(str(pkg_id))
                            ret_ += "\n~STICKER VERSION : {}".format(str(stk_ver))
                            ret_ += "\n~STICKER URL : line://shop/detail/{}".format(str(pkg_id))
                            ret_ += "\n~DESCRIPTION :\n"+soup.findAll('p', attrs={'elanksass':'mdCMN08Desc'})[0].text
                            elanks.sendMessage(msg.to, str(ret_))
                            query = int(stk_id)
                            if type(query) == int:
                               data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                               path = elanks.downloadFileURL(data)
                               elanks.sendImage(msg.to,path)
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    elanks.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = elanks.getContact(msg.contentMetadata["mid"])
                        path = elanks.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        elanks.sendMessage(msg.to," 「 Contact Info 」\n➸ Nama : " + msg.contentMetadata["displayName"] + "\n➸ MID : " + msg.contentMetadata["mid"] + "\n➸ Status Msg : " + contact.statusMessage + "\n➸ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        elanks.sendImageWithURL(msg.to, image)
               if msg.contentType == 13:
                if msg._from in admin:
                  if wait["invite"] == True:
                    msg.contentType = 0
                    contact = elanks.getContact(msg.contentMetadata["mid"])
                    invite = msg.contentMetadata["mid"]
                    groups = elanks.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if invite in wait["blacklist"]:
                            elanks.sendMessage(msg.to, "...")
                            break
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                         for target in targets:
                             try:
                                  elanks.findAndAddContactsByMid(target)
                                  elanks.inviteIntoGroup(msg.to,[target])
                                  ryan = elanks.getContact(target)
                                  zx = ""
                                  zxc = ""
                                  zx2 = []
                                  xpesan =  ""
                                  ret_ = "Ketik invite off jika Sudah Selesai"
                                  ry = str(ryan.displayName)
                                  pesan = ''
                                  pesan2 = pesan+"@x\n"
                                  xlen = str(len(zxc)+len(xpesan))
                                  xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                  zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                  zx2.append(zx)
                                  zxc += pesan2
                                  text = xpesan + zxc + ret_ + ""
                                  elanks.sendMessage(msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                  wait["invite"] = False
                                  break
                             except:
                                  elanks.sendMessage(msg.to,"🔄Anda terkena limit")
                                  wait["invite"] = False
                                  break
#ADD Bots
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        elanks.sendMessage(msg.to,"")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        elanks.sendMessage(msg.to,"Succes add Bost~")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        elanks.sendMessage(msg.to," Expelled")
                    else:
                        wait["dellbots"] = True
                        elanks.sendMessage(msg.to," Nothing from list")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        elanks.sendMessage(msg.to," Ready staff")
                        wait["addstaff"] = True
                    else:
                        staff[msg.contentMetadata["mid"]] = True
                        f=codecs.open('staff.json','w','utf-8')
                        json.dump(staff, f, sort_keys=True, indent=4,ensure_ascii=False)
                        wait["addstaff"] = True
                        elanks.sendMessage(msg.to,"Succes add to staff~")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        del staff[msg.contentMetadata["mid"]]
                        f=codecs.open('staff.json','w','utf-8')
                        json.dump(staff, f, sort_keys=True, indent=4,ensure_ascii=False)
                        elanks.sendMessage(msg.to,"Succes expell staff")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        elanks.sendMessage(msg.to,"Nothing in list staff")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        elanks.sendMessage(msg.to,"Ready in admin list")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        elanks.sendMessage(msg.to," Succes add to admin~")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        elanks.sendMessage(msg.to," Succes expell in admin list~")
                    else:
                        wait["delladmin"] = True
                        elanks.sendMessage(msg.to,"Nothing in admin list")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        elanks.sendMessage(msg.to," User ready in blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        elanks.sendMessage(msg.to,"Succes add blacklist user~")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        elanks.sendMessage(msg.to," Remove from blacklist user")
                    else:
                        wait["dblacklist"] = True
                        elanks.sendMessage(msg.to," Nothing in User blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        elanks.sendMessage(msg.to," Ready in User Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        elanks.sendMessage(msg.to," Succes add to Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        elanks.sendMessage(msg.to," Remove Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        elanks.sendMessage(msg.to," Ready in Talkban list")
#UPDATE FOTO
               if msg.contentType == 1:
                 if msg._from in admin:
                    if wait["Addimage"]["status"] == True:
                        path = elanks.downloadObjectMsg(msg.id)
                        images[wait["Addimage"]["name"]] = str(path)
                        f = codecs.open("image.json","w","utf-8")
                        json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                        elanks.sendMessage(msg.to, " Berhasil menambahkan gambar {}".format(str(wait["Addimage"]["name"])))
                        wait["Addimage"]["status"] = False                
                        wait["Addimage"]["name"] = ""
               #if msg.contentType == 2:
                 #if msg._from in admin:
                    #if wait["Addvideo"]["status"] == True:
                        #path = elanks.downloadObjectMsg(msg.id)
                        #videos[wait["Addvideo"]["name"]] = str(path)
                        #f = codecs.open("video.json","w","utf-8")
                        #json.dump(videos, f, sort_keys=True, indent=4, ensure_ascii=False)
                        #elanks.sendMessage(msg.to, " Berhasil menambahkan video {}".format(str(wait["Addvideo"]["name"])))
                        #wait["Addvideo"]["status"] = False                
                        #wait["Addvideo"]["name"] = ""
               if msg.contentType == 7:
                 if msg._from in admin:
                    if wait["Addsticker"]["status"] == True:
                        stickers[wait["Addsticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
                        f = codecs.open("sticker.json","w","utf-8")
                        json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                        elanks.sendMessage(msg.to, " Berhasil menambahkan sticker {}".format(str(wait["Addsticker"]["name"])))
                        wait["Addsticker"]["status"] = False                
                        wait["Addsticker"]["name"] = ""
               
               if msg.contentType == 3:
                 if msg._from in admin:
                    if wait["Addaudio"]["status"] == True:
                        path = elanks.downloadObjectMsg(msg.id)
                        audios[wait["Addaudio"]["name"]] = str(path)
                        f = codecs.open("audio.json","w","utf-8")
                        json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                        elanks.sendMessage(msg.to, " Berhasil menambahkan mp3 {}".format(str(wait["Addaudio"]["name"])))
                        wait["Addaudio"]["status"] = False                
                        wait["Addaudio"]["name"] = ""
               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = elanks.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     elanks.updateGroupPicture(msg.to, path)
                     elanks.sendMessage(msg.to, "Succes Update Profile Group~")
               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["RAfoto"]:
                            path = elanks.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][mid]
                            elanks.updateProfilePicture(path)
                            elanks.sendMessage(msg.to,"Update Profile Succes~")
               if msg.contentType == 2:
                   if msg._from in admin:
                       if mid in Setmain["RAvideo"]:
                            path = elanks.downloadObjectMsg(msg_id)
                            Setmain["RAvideo"][mid]
                            elanks.updateProfileVideoPicture(path)
                            elanks.sendMessage(msg.to," Succes~")
          
               if msg.contentType == 1:
                 if msg._from in admin:
                        if mid in Setmain["RAfoto"]:
                            path = elanks.downloadObjectMsg(msg_id)
                            Setmain["RAfoto"][mid]
                            elanks.updateProfilePicture(path)
                            elanks.sendMessage(msg.to,"Succes change~")
               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path = elanks.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     elanks.updateProfilePicture(path)
                     elanks.sendMessage(msg.to, " Succes ~")
               if msg.contentType == 0:
                 if Setmain["autoRead"] == True:
                     elanks.sendChatChecked(msg.to, msg_id)
                     elanks1.sendChatChecked(msg.to, msg_id)
                 if text is None:
                     return
                 else:
                        for sticker in stickers:
                         #if msg._from in admin:
                           if text.lower() == sticker:
                              sid = stickers[text.lower()]["STKID"]
                              spkg = stickers[text.lower()]["STKPKGID"]
                              elanks.sendSticker(to, spkg, sid)
                        for image in images:
                         if msg._from in admin:
                           if text.lower() == image:
                              elanks.sendImage(msg.to, images[image])
                        for audio in audios:
                         if msg._from in admin:
                           if text.lower() == audio:
                              elanks.sendAudio(msg.to, audios[audio])
                        #for video in videos:
                         #if msg._from in admin:
                           #if text.lower() == video:
                              #elanks.sendVideo(msg.to, videos[video])
                        cmd = command(text)
                        if cmd == "bot on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                elanks.sendMessage(msg.to, " ➪ Selfbot diaktifkan")
                                
                        elif cmd == "bot off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                elanks.sendMessage(msg.to, " 🚫 Selfbot dinonaktifkan")
#====================================================
                        elif cmd == "help1":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = help()
                               elanks.sendMessage(msg.to, str(helpMessage))
#====================================================
                        elif cmd == "help2":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage1 = commandMenu1()
                               elanks.sendMessage(msg.to, str(helpMessage1))
#====================================================
                        elif cmd == "help3":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage2 = commandMenu2()
                               elanks.sendMessage(msg.to, str(helpMessage2))
#====================================================
                        #elif cmd == "help1":
                            #elanks.sendMessage(to, "╭─────────\n│╭────────\n│├• 〔  ᴍᴇɴᴜ js  〕\n│╰────────\n│╭────────\n││➪ me \n││➪ menu1 \n││➪ menu2 \n││➪ mybot \n││➪ mycrot \n││➪ #bantai \n││➪ #hobah \n││➪ jiran <no> \n│╰────────\n│ ├•  by : elank_team \n╰─────────")
    
                        #elif cmd == "help2":
                            #elanks.sendMessage(to, "╭──────────\n│╭─────────\n│├• 〔  ᴍᴇɴᴜ 2 〕\n│╰─────────\n│╭─────────\n││➪ respon on/off \n││➪ autojoin on/off \n││➪ autoblock on/off \n││➪ autoriject on/off \n││➪ autoadd on/off \n││➪ autoreed on/off \n││➪ unsend on/off \n││➪ jointicket on/off \n││➪ chatbot on/off \n││➪ sticker on/off \n││➪ autolike on/off \n││➪ timeline on/off \n││➪ contact on/off \n││➪ invite on/off \n││➪ time on/off \n│╰─────────\n│ ├•  by : elank_team \n╰──────────")
    
                        #elif cmd == "help3":
                            #elanks.sendMessage(to, "╭────────────\n│╭───────────\n│├• 〔  ᴍᴇɴᴜ 3 〕\n│╰───────────\n│╭───────────\n││➪ set respon: <kata> \n││➪ set welcome: <kata> \n││➪ set leave: <kata> \n││➪ set tag: <kata> \n││➪ set ciluk: <kata> \n│╰─────────── \n│╭─────────── \n││➪ reboot \n││➪ hapus mantan \n││➪ ciluk ba \n││➪ colok ni \n││➪ blacklist \n││➪ ampuni \n││➪ maafin \n││➪ byeme \n││➪ blc \n││➪ ping \n││➪ open \n││➪ elanksose \n││➪ link \n││➪ glist \n│╰─────────\n│ ├•  by : elank_team \n╰──────────")
                            
                        elif cmd == "set":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "    😡 My Setting 😡 \n"
                                if wait["selfbot"] == True: md+="😡 ✔ Auto Chat\n"
                                else: md+="😡 ❎  Auto Chat\n"
                                if wait["mentionKick"] == True: md+="😡 ✔ Respon Kick\n"
                                else: md+="😡 ❎ Respon Kick\n"
                                if wait["stickerOn"] == True: md+="😡 ✔ Check Sticker\n"
                                else: md+="😡 ❎ Check Sticker\n"
                                if wait["contact"] == True: md+="😡 ✔ Check Contact\n"
                                else: md+="😡 ❎ Check Contact\n"
                                if wait["talkban"] == True: md+="😡 ✔ Talkban「On」\n"
                                else: md+="😡 ❎ Talkban\n"
                                if wait["autoBlock"] == True: md+="😡 ✔ Auto Block\n"
                                else: md+="😡 ❎ Auto Block\n"
                                if wait["detectMention"] == True: md+="😡 ✔ Auto Respon\n"
                                else: md+="😡 ❎ Auto Respon\n"
                                if wait["Timeline"] == True: md+="😡 ✔ Detail Post\n"
                                else: md+="😡 ❎ Detail Post\n"
                                if wait["autoJoin"] == True: md+="😡 ✔ Auto Join\n"
                                else: md+="😡 ❎ Auto Join\n"
                                if wait["autoAdd"] == True: md+="😡 ✔ Auto Add\n"
                                else: md+="😡 ❎ Auto Add\n"
                                if settings["autoJoinTicket"] == True: md+="😡 ✔ Join Link\n"
                                else: md+="😡 ❎ Join Link\n"
                                if msg.to in welcome: md+="😡 ✔ Sambutan\n"
                                else: md+="😡 ❎ Sambutan\n"
                                if wait["autoLeave"] == True: md+="😡 ✔ Auto Leave\n"
                                else: md+="😡 ❎ Auto Leave\n"
                                elanks.sendMessage(msg.to, md+"\n↘Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"+"\n↘Tanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d'))
                                
                        elif cmd == "creator" or text.lower() == 'cr':
                            if msg._from in admin:
                                elanks.sendMessage(msg.to," by : elank_team ") 
                                ma = ""
                                for i in creator:
                                    ma = elanks.getContact(i)
                                    elanks.sendMessage(msg.to, None, contentMetadata={'': i}, contentType=13)

                        elif cmd.startswith("joox"):
                            try:
                                proses = text.split(" ")
                                urutan = text.replace(proses[0] + " ","")
                                r = requests.get("http://api.zicor.ooo/joox.php?song={}".format(str(urllib.parse.quote(urutan))))
                                data = r.text
                                data = json.loads(data)
                                b = data
                                c = str(b["title"])
                                d = str(b["singer"])
                                e = str(b["url"])
                                g = str(b["image"])
                                hasil = "Penyanyi: "+str(d)
                                hasil += "\nJudul : "+str(c)
                                elanks.sendImageWithURL(to,g)
                                elanks.sendAudioWithURL(to,e)
                                elanks.sendMessage(msg.to,hasil)
                            except Exception as error:
                                elanks.sendMessage(to, "error\n" + str(error))
                                logError(error) 

                        elif cmd.startswith('about'):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                            try:
                                arr = []
                                today = datetime.today()
                                thn = 2018 
                                bln = 5     #isi bulannya yg sewa
                                hr = 17    #isi tanggalnya yg sewa
                                future = datetime(thn, bln, hr)
                                days = (str(future - today))
                                comma = days.find(",")
                                days = days[:comma]
                                contact = elanks.getContact(mid)
                                favoritelist = elanks.getFavoriteMids()
                                grouplist = elanks.getGroupIdsJoined()
                                contactlist = elanks.getAllContactIds()
                                blockedlist = elanks.getBlockedContactIds()
                                eltime = time.time() - mulai
                                bot = runtime(eltime)
                                start = time.time()
                                elanks.sendMessage("uc1810aa6facc5a7c33227784312151ff", '.')
                                elapsed_time = time.time() - start
                                ryan = elanks.getContact(mid)
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "😡 Info Selfbot 😡\n😡 Name : "
                                ret_ = "😡 Group : {} Group".format(str(len(grouplist)))
                                ret_ += "\n• Friend : {} Friend".format(str(len(contactlist)))
                                ret_ += "\n• Blocked : {} Blocked".format(str(len(blockedlist)))
                                ret_ += "\n• Favorite : {} Favorite".format(str(len(favoritelist)))
                                ret_ += "\n• Version : Py3"
                                ret_ += "\n• Expired : {} - {} - {}".format(str(hr), str(bln), str(thn))
                                ret_ += "\n•In days : {} again".format(days)
                                ret_ += "\n 😡 Speed Respon 😡\n• {} detik".format(str(elapsed_time))
                                ret_ += "\n😡 Selfbot Runtime 😡\n• {}".format(str(bot))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                elanks.sendMessage(to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                elanks.sendContact(to, "uc28284eca396bd65511797a2ce6d6167")
                            except Exception as e:
                                elanks.sendMessage(msg.to, str(e))

                        elif cmd == "me":
                           if wait["selfbot"] == True:
                             if msg._from in admin:
                                 elanks.sendMentionFooter(to, '[ elanks__BOTS ]\n', sender, "https://line.me/ti/p/~elanksbots.py", "http://dl.profile.line-cdn.net/"+elanks.getContact(sender).pictureStatus, elanks.getContact(sender).displayName);elanks.sendMessage(to, elanks.getContact(sender).displayName, contentMetadata = {'previewUrl': 'http://dl.profile.line-cdn.net/'+elanks.getContact(sender).pictureStatus, 'i-installUrl': 'https://line.me/ti/p/elanksbots.py', 'type': 'mt', 'subText': "elanks_Bots", 'a-installUrl': 'https://line.me/ti/p/elanksbots.py', 'a-installUrl': ' https://line.me/ti/p/elanksbots.py', 'a-packageName': 'com.spotify.music', 'countryCode': 'ID', 'a-linkUri': 'https://line.me/ti/p/elanksbots.py', 'i-linkUri': 'https://line.me/ti/p/elanksbots.py', 'id': 'mt000000000a6b79f9', 'text': 'elanks__Bots', 'linkUri': 'https://line.me/ti/p/elanksbots.py'}, contentType=19)
                        elif text.lower() == "mid":
                               elanks.sendMessage(msg.to, msg._from)
                        elif cmd.startswith("mid "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = elanks.getContact(key1)
                               elanks.sendMessage(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               elanks.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif ("Steal " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = elanks.getContact(key1)
                               a = elanks.getProfileCoverURL(mid=key1)
                               elanks.sendMessage(msg.to, "「 Contact Info 」\n• Nama : "+str(mi.displayName)+"\n• Mid : " +key1+"\n• Status Msg"+str(mi.statusMessage))
                               elanks.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(elanks.getContact(key1)):
                                   elanks.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                                   elanks.sendImageWithURL(receiver, a)
                               else:
                                   elanks.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))
                                   elanks.sendImageWithURL(receiver, a)

                        elif ("Cover " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    u = key["MENTIONEES"][0]["M"]
                                    a = elanks.getProfileCoverURL(mid=u)
                                    elanks.sendImageWithURL(receiver, a)
                                except Exception as e:
                                    elanks.sendMessage(receiver, str(e))

                        elif ("Sticker: " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    query = msg.text.replace("Sticker: ", "")
                                    query = int(query)
                                    if type(query) == int:
                                        elanks.sendImageWithURL(receiver, 'https://stickershop.line-scdn.net/stickershop/v1/product/'+str(query)+'/ANDROID/main.png')
                                        elanks.sendMessage(receiver, 'https://line.me/S/sticker/'+str(query))
                                    else:
                                        elanks.sendMessage(receiver, 'gunakan key sticker angka bukan huruf')
                                except Exception as e:
                                    elanks.sendMessage(receiver, str(e))

                        elif "/ti/g/" in msg.text.lower():
                           if msg._from in admin:
                             if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                    if l not in n_links:
                                       n_links.append(l)
                                 for ticket_id in n_links:
                                    group = elanks.findGroupByTicket(ticket_id)
                                    elanks.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    elanks.sendMessage(msg.to, "~Joint : %s" % str(group.name))
                                    group1 = elanks1.findGroupByTicket(ticket_id)
                                    elanks1.acceptGroupInvitationByTicket(group1.id,ticket_id)
                                    elanks1.sendMessage(msg.to, "~Joint : %s" % str(group.name))
                                    
                        elif cmd.startswith('cek'):
                          if wait["selfbot"] == True:
                            if msg._from in creator or msg._from in owner or msg._from in admin:
                                try:elanks.kickoutFromGroup(msg.to, ["u5d72909e8c37e0ab805952336f872361"]);wait["limitkick"] = False
                                except:wait["limitkick"] = True
                                md = ""
                                if wait["limitkick"]== True: md+="❎ Limite"
                                else: md+="😡✔ Sehat"
                                elanks.sendMessage(msg.to, md)
                                
                        elif cmd == "reject":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ginvited = elanks.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      elanks.rejectGroupInvitation(gid)
                                  elanks.sendMessage(to, "~ Berhasil tolak sebanyak {} undangan grup".format(str(len(ginvited))))
                              else:
                                  elanks.sendMessage(to, "~ Tidak ada undangan yang tertunda")
                                  
                        elif cmd.startswith("delfriend "):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = elanks.getContact(ls)
                                    elanks.deleteContact(ls)
                                elanks.sendMessage(to, "Success Del " + str(contact.displayName) + " to Friendlist")
                        elif cmd.startswith("addfriend "):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = elanks.getContact(ls)
                                    elanks.findAndAddContactsByMid(ls)
                                elanks.sendMessage(to, "Success Add " + str(contact.displayName) + " to Friendlist")

                        elif text.lower() == "hapus chat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   elanks.removeAllMessages(op.param2)
                               except:
                                   pass

                        elif text.lower() == "hapus mantan":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   elanks.removeAllMessages(op.param2)
                                   elanks.sendMessage(msg.to,"мᴀɴтᴀɴ ᴅιмusɴᴀнκᴀɴ~.")
                                   elanks.sendMessage(msg.to,"мᴀɴтᴀɴ мusɴᴀн~.")
                               except:
                                   pass

                        elif cmd.startswith("bc: "):
                           if msg._from in admin:
                             sep = text.split(" ")
                             bc = text.replace(sep[0] + " ","")
                             saya = elanks.getGroupIdsJoined()
                             for group in saya:
                                ryan = elanks.getContact(mid)
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "◀Broadcast ▶\n↘By "
                                ret_ = "{}".format(str(bc))
                                ry = str(ryan.displayName)
                                pesan = '~'
                                pesan2 = pesan+"@x\n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                elanks.sendMessage(group, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                             
                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               elanks.sendMessage(msg.to, "↘ " + str(Setmain["keyCommand"]) + " ")
                               
                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   elanks.sendMessage(msg.to, "🔄Gagal mengganti key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   elanks.sendMessage(msg.to, "↘Setkey diganti jadi「{}」".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               elanks.sendMessage(msg.to, " Setkey Anda telah direset")

                        elif cmd == "reboot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               elanks.sendMessage(to,"Waaiiit..... ⏳")
                               Setmain["restartPoint"] = msg.to
                               time.sleep(3)
                               elanks.sendMessage(to,"███▒▒▒▒▒▒▒")
                               time.sleep(2)
                               elanks.sendMessage(to,"█████▒▒▒▒▒")
                               time.sleep(2)
                               elanks.sendMessage(to,"██████████")
                               time.sleep(2)
                               elanks.sendMessage(to,"~Bots Actived..✔")
                               restartBot()                            
                            
                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                eltime = time.time() - mulai
                                bot = runtime(eltime)
                                ryan = elanks.getContact(mid)
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "↘User : "
                                ret_ = "• {}".format(str(bot))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                elanks.sendMessage(to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = elanks.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(elanks.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                elanks.sendMessage(msg.to, "↘Group Info↖\n↘Nama Group : {}".format(G.name)+ "\n↘ID Group : {}".format(G.id)+ "\n↘Pembuat : {}".format(G.creator.displayName)+ "\n↘Waktu Dibuat : {}".format(str(timeCreated))+ "\n↘Jumlah Member : {}".format(str(len(G.members)))+ "\n↘Jumlah Pending : {}".format(gPending)+ "\n↘Group Qr : {}".format(gQr)+ "\n↘Group Ticket : {}".format(gTicket))
                                elanks.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                elanks.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                elanks.sendMessage(msg.to, str(e))

                        elif cmd == "invite":
                          if msg._from in admin:
                                wait['undang'] = True
                                elanks.sendMessage(to,"Send Contact For Invite Target")
                         
                        elif cmd.startswith("infogrup "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = elanks.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = elanks.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(elanks.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += " ◀ Group Info ▶"
                                ret_ += "\n➥Nama Group : {}".format(G.name)
                                ret_ += "\n➥ID Group : {}".format(G.id)
                                ret_ += "\n➥Pembuat : {}".format(gCreator)
                                ret_ += "\n➥Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n➥Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n➥Jumlah Pending : {}".format(gPending)
                                ret_ += "\n➥Group Qr : {}".format(gQr)
                                ret_ += "\n➥Group Ticket : {}".format(gTicket)
                                ret_ += "\n➥Picture Url : http://dl.profile.line-cdn.net/{}".format(G.pictureStatus)
                                ret_ += ""
                                elanks.sendMessage(to, str(ret_))
                                elanks.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except:
                                pass
                                
                        elif cmd.startswith("outqr "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = elanks.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = elanks.getGroup(group)
                            #elanks.sendMessage(msg.to, "Bots di paksa keluar oleh Owner")
                            try:
                                elanks.leaveGroup(group)
                                elanks.sendMessage(msg.to,"~Succes Leave from~ Group \n"+str(G.name))
                            except:
                                pass
                        elif cmd.startswith("openqr "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = elanks.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = elanks.getGroup(group)
                            try:
                                elanks.updateGroup(G)
                                gurl = elanks.reissueGroupTicket(group)
                                elanks.sendMessage(msg.to, "Group "+str(G.name)+ "\nLink nya : http://line.me/R/ti/g/"+gurl)
                            except:
                            	elanks.sendMessage(msg.to,"I no there")
                                        
                        elif cmd.startswith("invitegid: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = elanks.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = elanks.getGroup(group)
                            if gid == "":
                                    elanks.sendMessage(msg.to,"Group id wrong")
                                    try:
                                        elanks.findAndAddContactsByMid(MID)
                                        elanks.inviteIntoGroup(gid,[MID])
                                    except:
                                    	pass
                        elif cmd.startswith("groupid: "):
                          if msg._from in owner or msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = elanks.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = elanks.getGroup(group)
                            gid = elanks.getGroup(to)
                            try:
                                elanks.sendMessage(to, "~"+str(G.name) + "\n" +gid.id)
                            except:
                            	pass     
                        elif cmd.startswith("leaveall "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = elanks.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = elanks.getGroup(group)
                            try:
                                elanks1.leaveGroup(group)
                                elanks.sendMessage(msg.to,"Succes leaveall from group~\n" + str(G.name))
                            except:
                                pass

                        elif cmd.startswith("open "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = elanks.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = elanks.getGroup(group)
                                G.preventedJoinByTicket = False
                                elanks.updateGroup(G)
                                elanks.sendMessage(msg.to,"Succes Open Qr in group~\n" + str(G.name))
                            except:
                                pass

                        elif cmd.startswith("elanksose "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = elanks.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = elanks.getGroup(group)
                                G.preventedJoinByTicket = True
                                elanks.updateGroup(G)
                                elanks.sendMessage(msg.to,"Succes elanksose Qr in group~\n" + str(G.name))
                            except:
                                pass

                        elif cmd.startswith("open "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = elanks1.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = elanks1.getGroup(group)
                                G.preventedJoinByTicket = False
                                elanks1.updateGroup(G)
                                elanks1.sendMessage(msg.to,"Succes Open Qr in group~\n" + str(G.name))
                            except:
                                pass

                        elif cmd.startswith("elanksose "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = elanks1.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = elanks1.getGroup(group)
                                G.preventedJoinByTicket = True
                                elanks1.updateGroup(G)
                                elanks1.sendMessage(msg.to,"Succes elanksose Qr in group~\n" + str(G.name))
                            except:
                                pass
                                
                        elif cmd == "gid":
                          if msg._from in admin:
                            if msg.toType != 2: return
                            gid = elanks.getGroup(to)
                            elanks.sendMessage(to, "" + gid.id)
              
                        elif cmd.startswith("infomem "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = elanks.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = elanks.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "➥ "+ str(no) + ". " + mem.displayName
                                elanks.sendMessage(to,"~ Group Name : ◀ " + str(G.name) + " ▶\n\n   [ List Member ]\n" + ret_ + "\n\n[Total %i Members]" % len(G.members))
                            except: 
                                pass
                        elif cmd == "glist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = elanks.getGroupIdsJoined()
                               for i in gid:
                                   G = elanks.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               elanks.sendMessage(msg.to,"╭──〔Grup Bahan 〕\n│\n"+ma+"│\n╰──〔 Ada「"+str(len(gid))+"」BahanTest 〕")
                        elif cmd == "glistjs":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = elanks1.getGroupIdsJoined()
                               for i in gid:
                                   G = elanks.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               elanks1.sendMessage(msg.to,"╭──〔Grup Bahan 〕\n│\n"+ma+"│\n╰──〔 Ada「"+str(len(gid))+"」BahanTest 〕")

                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = elanks.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   elanks.updateGroup(X)
                                   elanks.sendMessage(msg.to, "➥Succes Open Code qr  ...")

                        elif cmd == "elanksose":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = elanks.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   elanks.updateGroup(X)
                                   elanks.sendMessage(msg.to, "➥Succes elanksosed Qr Code.....")
                                   
                        elif cmd == "link":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = elanks.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      elanks.updateGroup(x)
                                   gurl = elanks.reissueGroupTicket(msg.to)
                                   elanks.sendMessage(msg.to, "Grup "+str(x.name)+ "\nLink nya : http://line.me/R/ti/g/"+gurl)
                                   
                        elif cmd == "link":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = elanks1.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      elanks1.updateGroup(x)
                                   gurl = elanks.reissueGroupTicket(msg.to)
                                   elanks1.sendMessage(msg.to, "Grup "+str(x.name)+ "\nLink nya : http://line.me/R/ti/g/"+gurl)

#===========BOT UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                elanks.sendMessage(msg.to,"➥Kirim fotonya.....")

                        elif cmd == "updatebot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                elanks.sendMessage(msg.to,"➥Kirim fotonya.....")
                                elanks1.sendMessage(msg.to,"➥Kirim fotonya.....")
                                
                        elif cmd == "updatefoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                elanks.sendMessage(msg.to,"➥Kirim fotonya.....")
                                
                        elif cmd == "upjs":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                elanks1.sendMessage(msg.to,"➥Kirim fotonya.....")

                        elif cmd == "cvp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAvideo"][mid] = True
                                elanks.sendMessage(msg.to,"➥Kirim videonya.....")
                                
                        elif cmd.startswith("status "):
                          if msg._from in admin:
                            string = removeCmd("updatestatus", text)
                            if len(string) <= 10000000000:
                                pname = elanks.getContact(sender).statusMessage
                                profile = elanks.getProfile()
                                profile.statusMessage = string
                                elanks.updateProfile(profile)
                                elanks.sendMessage(to ,"~Success")
                                
                        elif cmd.startswith("name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = elanks.getProfile()
                                profile.displayName = string
                                elanks.updateProfile(profile)
                                elanks.sendMessage(msg.to,"➥Nama diganti jadi " + string + "")
                                
                        elif cmd.startswith("namejs: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = elanks1.getProfile()
                                profile.displayName = string
                                elanks1.updateProfile(profile)
                                elanks1.sendMessage(msg.to,"➥Nama diganti jadi " + string + "")
#===========COMEN PANGGILAN======
                        elif cmd.startswith("stag: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                elanks.sendMessage(msg.to,"Spamtag Diubah Menjadi " +strnum)
                        elif cmd.startswith("scall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                elanks.sendMessage(msg.to,"Spamcall Diubah Menjadi " +strnum)
                        elif cmd.startswith("stag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []                                
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(wait["limit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                elanks.sendMessage1(msg)
                                            except Exception as e:
                                                elanks.sendText(msg.to,str(e))
                                    else:
                                        elanks.sendMessage(msg.to,"Jumlah melebihi 1000")                          
                        elif msg.text.lower().startswith("naik "):
                          if msg._from in admin:
                           if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                               names = re.findall(r'@(\w+)', text)
                               mention = eval(msg.contentMetadata['MENTION'])
                               mentionees = mention['MENTIONEES']
                               lists = []
                               for mention in mentionees:
                                   if mention["M"] not in lists:
                                       lists.append(mention["M"])
                               for ls in lists:
                                   contact = elanks.getContact(ls)                          
                                   jmlh = int(wait["limit"])
                                   elanks.sendMessage(msg.to, "Succes {} Call Grup".format(str(wait["limit"])))
                                   if jmlh <= 1000:
                                     for x in range(jmlh):
                                         try:
                                             mids = [contact.mid]
                                             elanks.acquireGroupCallRoute(msg.to)
                                             elanks.inviteIntoGroupCall(msg.to,mids)
                                         except Exception as e:
                                             elanks.sendMessage(msg.to,str(e))
                                     else:
                                         elanks.sendMessage(msg.to,"")
                        elif cmd == "scall":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = elanks.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                                elanks.sendMessage(msg.to, "Sukses Call {} diGrup".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        elanks.acquireGroupCallRoute(to)
                                        elanks.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        elanks.sendText(msg.to,str(e))
                                else:
                                    elanks.sendMessage(msg.to,"Jumlah melebihi batas")
                                
                        elif cmd.startswith("jiran "):
                          if msg._from in admin:
                           separate = text.split(" ")
                           number = text.replace(separate[0] + " ","")
                           groups = elanks.getGroupIdsJoined()
                           groups = elanks.getGroupIdsJoined()
                           listGroup = groups[int(number)-1]
                           x = elanks.getGroup(listGroup)
                           x = elanks.getGroup(listGroup)
                           if x.invitee == None:nama = []
                           else:nama = [contact.mid for contact in x.invitee]
                           targets = []
                           for a in nama:
                           	if a not in ["ud9e93f564195bf069e43b9801d8af3a5",elanks.profile.mid]:targets.append(a) 
                           nami = [contact.mid for contact in x.members]
                           targetk = []
                           lolz = 'dual.js gid={} token={}'.format(x.id, elanks.authToken)
                           for a in nami:
                           	if a not in ["ud9e93f564195bf069e43b9801d8af3a5",elanks.profile.mid]:targetk.append(a) 
                           for y in targets:
                           	lolz += ' uid={}'.format(y)
                           for y in targetk:
                           	lolz += ' uik={}'.format(y)
                           elanks.sendMessage(to,':..｡ᴏ○ sᴀᴍᴜᴅʀᴀ__ʙᴏᴛs ○ᴏ｡..:')
                           print(lolz)
                           success = execute_js(lolz)
                           if success:
                           	elanks.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : ᴍisɪᴏɴ bypas ᴛᴀʀɢᴇᴛ??\n•Jᴜᴍʟᴀʜ : %i" % len(targets)+"\n•sᴛᴀᴛᴜs : 𝘴𝘢𝘮𝘶𝘥𝘳𝘢 𝘴𝘶𝘤𝘴𝘦𝘴 𝘤𝘰𝘭𝘪", [sender])
                           else:
                           	elanks.sendMessage(to,'error')
                                
                        elif cmd.startswith("jiran "):
                          if msg._from in admin:
                           separate = text.split(" ")
                           number = text.replace(separate[0] + " ","")
                           groups = elanks1.getGroupIdsJoined()
                           groups = elanks1.getGroupIdsJoined()
                           listGroup = groups[int(number)-1]
                           x = elanks1.getGroup(listGroup)
                           x = elanks1.getGroup(listGroup)
                           if x.invitee == None:nama = []
                           else:nama = [contact.mid for contact in x.invitee]
                           targets = []
                           for a in nama:
                           	if a not in ["ud9e93f564195bf069e43b9801d8af3a5",elanks1.profile.mid]:targets.append(a) 
                           nami = [contact.mid for contact in x.members]
                           targetk = []
                           lolz = 'dual.js gid={} token={}'.format(x.id, elanks1.authToken)
                           for a in nami:
                           	if a not in ["ud9e93f564195bf069e43b9801d8af3a5",elanks1.profile.mid]:targetk.append(a) 
                           for y in targets:
                           	lolz += ' uid={}'.format(y)
                           for y in targetk:
                           	lolz += ' uik={}'.format(y)
                           elanks1.sendMessage(to,':..｡ᴏ○ sᴀᴍᴜᴅʀᴀ__ʙᴏᴛs ○ᴏ｡..:')
                           print(lolz)
                           success = execute_js(lolz)
                           if success:
                           	elanks1.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : ᴍisɪᴏɴ bypas ᴛᴀʀɢᴇᴛ??\n•Jᴜᴍʟᴀʜ : %i" % len(targets)+"\n•sᴛᴀᴛᴜs : 𝘴𝘢𝘮𝘶𝘥𝘳𝘢 𝘴𝘶𝘤𝘴𝘦𝘴 𝘤𝘰𝘭𝘪", [sender])
                           else:
                           	elanks1.sendMessage(to,'error')
                           
                        elif cmd.startswith("ruduk "):
                         if msg._from in admin:
                          xyz = elanks.getGroup(to)
                          if xyz.invitee == None:pends = []
                          else:pends = [c.mid for c in xyz.invitee]
                          targp = []
                          for x in pends:
                            if x not in ["u5d5d8f736b9b730ddab0c89d45cd5585",elanks.profile.mid]:targp.append(x)
                          mems = [c.mid for c in xyz.members]
                          targk = []
                          for x in mems:
                            if x not in ["u5d5d8f736b9b730ddab0c89d45cd5585",elanks.profile.mid]:targk.append(x)
                          lolz = 'dual.js gid={} token={}'.format(to, elanks.authToken)
                          for x in targp:lolz += ' uid={}'.format(x)
                          for x in targk:lolz += ' uik={}'.format(x)
                          execute_js(lolz)
         
                        elif cmd == "#bantai" or cmd == "#hobah":
                          if msg._from in admin:
                            xyz = elanks.getGroup(to)
                            if xyz.invitee == None:pends = []
                            else:pends = [c.mid for c in xyz.invitee]
                            targp = []
                            for x in pends:
                            	if x not in admin:
                                    targp.append(x)
                            mems = [c.mid for c in xyz.members]
                            targk = []
                            for x in mems:
                            	if x not in admin:
                                    targk.append(x)
                            imnoob = 'dual.js gid={} token={}'.format(to, elanks.authToken, "DESKTOPWIN\t5.20.2\tWindows\t10")
                            for x in targp:imnoob += ' uid={}'.format(x)
                            for x in targk:imnoob += ' uik={}'.format(x)
                            execute_js(imnoob)
         
                        elif cmd == "#ajsbantay" or cmd == "#ajshobah":
                          if msg._from in admin:
                            xyz = elanks1.getGroup(to)
                            if xyz.invitee == None:pends = []
                            else:pends = [c.mid for c in xyz.invitee]
                            targp = []
                            for x in pends:
                            	if x not in admin:
                                    targp.append(x)
                            mems = [c.mid for c in xyz.members]
                            targk = []
                            for x in mems:
                            	if x not in admin:
                                    targk.append(x)
                            imnoob = 'dual.js gid={} token={}'.format(to, elanks1.authToken, "DESKTOPWIN\t5.20.2\tWindows\t10")
                            for x in targp:imnoob += ' uid={}'.format(x)
                            for x in targk:imnoob += ' uik={}'.format(x)
                            execute_js(imnoob)
#===========BOT UPDATE============#     
                        elif msg.text.lower() in wait["tagall"]:
                          if msg._from in admin:        
                            if wait["selfbot"] == True:
                              if msg._from in owner or msg._from in admin or msg._from in staff:  
                                group = elanks.getGroup(msg.to)
                                nama = [contact.mid for contact in group.members]
                                k = len(nama)//20
                                for a in range(k+1):
                                    txt = u''
                                    s=0
                                    b=[]
                                    for i in group.members[a*20 : (a+1)*20]:
                                        b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                        s += 7
                                        txt += u'@Alin \n'
                                    elanks.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                                    elanks.sendMessage(to, "◀Mention {} Member▶".format(str(len(nama)))) 
                        elif cmd == "tag":
                          if msg._from in admin:        
                            if wait["selfbot"] == True:
                              if msg._from in owner or msg._from in admin or msg._from in staff:  
                                group = elanks.getGroup(msg.to)
                                nama = [contact.mid for contact in group.members]
                                k = len(nama)//20
                                for a in range(k+1):
                                    txt = u''
                                    s=0
                                    b=[]
                                    for i in group.members[a*20 : (a+1)*20]:
                                        b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                        s += 7
                                        txt += u'@Alin \n'
                                    elanks.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                                    elanks.sendMessage(to, "◀Mention {} Member▶".format(str(len(nama))))     
                                    
                        elif "ngikil" in msg.text:  
                           if msg._from in admin:
                            if msg.toType == 2:
                             #  print "Otw elankseanse"
                               _name = msg.text.replace("ngikil","")
                               gs = elanks1.getGroup(msg.to)
                               elanks1.sendMessage(msg.to,"Assalamualaikum")
                               elanks1.sendMessage(msg.to,"oit boskuh\n"
 "Ada room bahan kagak ni gua bawa tenk\n"
". ___________________\n"
"▕╮╭┻┻╮╭┻┻╮╭▕╮╲\n"
"▕╯┃╭╮┃┃╭╮┃╰▕╯╭▏\n"
"▕╭┻┻┻┛┗┻┻┛   ▕  ╰▏\n"
"▕╰━━━┓┈┈┈╭╮▕╭╮▏\n"
"▕╭╮╰┳┳┳┳╯╰╯▕╰╯▏\n"
"▕╰╯┈┗┛┗┛┈╭╮▕╮┈▏\n"
   " <,︻╦̵̵̿╤━ ҉     ~  •"
"   █۞██████]▄▄▄▄▄▄▃●●\n"
"   ▂▄▅███████▅▄▃▂"
"[█████████████████]\n"
"[██████████████████]\n"
"◥⊙⊙▲⊙▲⊙▲⊙▲⊙▲⊙\n"
" ☠↘sᴀмuᴅʀᴀ__ʙoтs↙☠\n"
"☾тᴇᴀм sᴀмuᴅʀᴀ___ʙoтs☽\n"
"cʀᴇᴀтoʀ sᴀмuᴅʀᴀ__ʙoтs☛ʙʏ : sᴀмuᴅʀᴀ\n"
"cʀᴇᴀтoʀ : \nhttps://line.me/ti/p/~elanksbots.py")
                               invitee = [contact.mid for contact in group.invitee]
                               targets = []
                               for g in gs.members:
                                   #if group.invitee is None or group.invitee == []:
                                   if _name in g.displayName:
                                       targets.append(g.mid)
                               if targets == []:
                                  elanks1.sendMessage(msg.to,"Sorry")
                              #    else:
                               for target in targets:
                                     if target not in Bots:
                                      try:
                                          kicker.cancelGroupInvitation(to, [inv])
                                          klist=[elanks1]
                                          kicker=random.choice(klist)
                                          kicker.kickoutFromGroup(msg.to,[target])
                                          print (msg.to,[g.mid])
                                      except:
                                          elanks1.sendMessage(msg.to,"I'm Sory")
 #============================================#
                              
                        elif cmd == "respon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                elanks1.sendMessage(msg.to,'☾тᴇᴀм sᴀмuᴅʀᴀ___ʙoтs☽✍')

                        elif cmd == "mybot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Musik(to, mid)
                                Musik(to, Amid)
                        
                        elif cmd == "ping":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                elanks.sendMessage(msg.to,'pong.....😡😡😡!!')
                                elanks1.sendMessage(msg.to,'pong.....😡😡😡!!')

                        elif cmd == "byme":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = elanks.getGroup(msg.to)
                                elanks.sendMessage(msg.to, "Bye bye coy "+str(G.name))
                                elanks.leaveGroup(msg.to)

                        elif cmd == "speed" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               start = time.time()
                               elanks.sendMessage(msg.to," 🔀 Wifi Direct")
                               elapsed_time = time.time() - start
                               elanks.sendMessage(msg.to, "↘{} Perdetik".format(str(elapsed_time)))
                               
                        elif cmd == "ciluk ba":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  elanks.sendMessage(to,"Mode sider diaktivkan✔ By " + elanks.getContact(sender).displayName)
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "colok ni":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  elanks.sendMessage(to,"Mode sider dinonaktivkan✔ By " + elanks.getContact(sender).displayName)
                              else:
                                  elanks.sendMessage(msg.to, " 🚫 Sudak tidak aktif")

#===================Protection============#
                        elif 'Welcome ' in msg.text:
                           if msg._from in owner or msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = " ➪ Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = elanks.getGroup(msg.to)
                                       msgs = ""
                                  elanks.sendMessage(to,"Welcome di aktifkan ✔ By " + elanks.getContact(sender).displayName)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = elanks.getGroup(msg.to)
                                         msgs = ""
                                    else:
                                         msgs = "➪ Sudah tidak aktif"
                                    elanks.sendMessage(to,"Non actived Welcome✔ By " + elanks.getContact(sender).displayName)
#===========KICKOUT============#
                        elif "Kick " in msg.text:
                            if msg._from in admin:                                                                                                                                       
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]                                                                                                                                
                                targets = []
                                for x in key["MENTIONEES"]:                                                                                                                                  
                                    targets.append(x["M"])
                                for target in targets:                                                                                                                                       
                                    try:
                                        elanks.kickoutFromGroup(msg.to,[target])
                                        elanks.inviteIntoGroup(msg.to,[target])
                                        elanks.cancelGroupInvitation(msg.to,[target])
                                    except:
                                        pass
            
#===========ADMIN ADD============#
                        elif ("Adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           elanks.sendMessage(to,"Add Admin ✔ By " + elanks.getContact(sender).displayName)
                                       except:
                                           pass

                        elif ("Staffadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff[target] = True
                                           f=codecs.open('staff.json','w','utf-8')
                                           json.dump(staff, f, sort_keys=True, indent=4,ensure_ascii=False)
                                           elanks.sendMessage(to,"Add Staff ✔ By " + elanks.getContact(sender).displayName)
                                       except:
                                           pass

                        elif ("Admindell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.remove(target)
                                           elanks.sendMessage(to,"Admin Expelled ✔ By " + elanks.getContact(sender).displayName)
                                       except:
                                           pass

                        elif ("Staffdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del staff[target]
                                           f=codecs.open('staff.json','w','utf-8')
                                           json.dump(staff, f, sort_keys=True, indent=4,ensure_ascii=False)
                                           elanks.sendMessage(to,"Staff Expelled ✔ By " + elanks.getContact(sender).displayName)
                                       except:
                                           pass
                                           
                        elif msg.text in ["invite on"]:
                            if msg._from in admin:
                                wait["Invi"] = True
                                elanks.sendMessage(msg.to,"sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ")
                                
                        elif msg.text in ["invit off"]:
                            if msg._from in admin:
                                wait["Invi"] = False
                                elanks.sendMessage(msg.to,"invite sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ off")        

                        elif cmd == "refresh":
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                Setmain["RAfoto"] = False
                                settings["changePicture"] = False
                                elanks.sendMessage(msg.to," ✔ Ringan dah ♩")
                                elanks.sendMessage(msg.to,"Refresh done 💯♩")

                        elif cmd == "mycrit" or text.lower() == 'mycrot':
                            if msg._from in admin:
                                ma = ""
                                for i in Bots:
                                    ma = elanks.getContact(i)
                                    elanks.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                                    elanks1.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif cmd == "unsend on" or text.lower() == 'unsend on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["cekUnsend"] = True
                                sendMention(msg.to, sender, "User ", "\n ✔ Silahkan unsend pesannya,\nKetik unsend off jika sudah slesai")

                        elif cmd == "unsend off" or text.lower() == 'unsend off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["cekUnsend"] = False
                                sendMention(msg.to, sender, "User ", " \n 🚫 Deteksi unsend dinonaktifkan")
                                
                        elif cmd == "timeline on" or text.lower() == 'timeline on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Timeline"] = True
                                elanks.sendMessage(msg.to," ✔ Check Timeline actived ")

                        elif cmd == "timeline off" or text.lower() == 'timeline off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Timeline"] = False
                                elanks.sendMessage(msg.to," 🚫 Check Timeline Nonactived ")
                                
                        elif cmd == "invite on" or text.lower() == 'invite on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = True
                                elanks.sendMessage(msg.to," ✔ Invte by Contact actived ")

                        elif cmd == "invite off" or text.lower() == 'invite off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = False
                                elanks.sendMessage(msg.to,"🚫 Nonactived ")
                                
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["mentionKick"] = True
                                elanks.sendMessage(msg.to,"✔ Responkick Actived")

                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["mentionKick"] = False
                                elanks.sendMessage(msg.to,"🚫Nonactived")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                elanks.sendMessage(msg.to," ✔ Check Contact actived ")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                elanks.sendMessage(msg.to,"?? Deteksi contact dinonaktifkan")

                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                elanks.sendMessage(msg.to,"✔Auto respon actived")

                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                elanks.sendMessage(msg.to,"🚫 Auto respon dinonaktifkan")

                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoin"] = True
                                elanks.sendMessage(msg.to,"✔ Autojoin actived")

                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoin"] = False
                                elanks.sendMessage(msg.to,"🚫 Autojoin telah dinonaktifkan")
                                
                        elif cmd == "autoread off" or text.lower() == 'auto read off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = False
                                elanks.sendMessage(msg.to," 🚫 AutoRead telah dinonaktifkan")

                        elif cmd == "autoread on" or text.lower() == 'auto read on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = True
                                elanks.sendMessage(msg.to,"  ✔ AutoRead telah diaktifkan")
                                
                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                elanks.sendMessage(msg.to," ✔ Autoleave telah diaktifkan")
                                
                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                elanks.sendMessage(msg.to,"🚫 Autoleave Nonactived")
                                
                        elif cmd == "autoblock on" or text.lower() == 'block on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                elanks.sendMessage(msg.to," ✔Autoblock Actived.....")

                        elif cmd == "autoblock off" or text.lower() == 'block off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                elanks.sendMessage(msg.to," 🚫  Non Actived.....")                                
                        elif cmd == "autolike on" or text.lower() == 'like on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeOn"] = True
                                elanks.sendMessage(msg.to," ✔ Autoalike Actived")
                        elif cmd == "autolike off" or text.lower() == 'like off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeOn"] = False
                                elanks.sendMessage(msg.to," ✔ Autolike Nonactived")
                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                elanks.sendMessage(msg.to,"✔ Autoadd telah diaktifkan")

                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                elanks.sendMessage(msg.to,"🚫 Autoadd telah dinonaktifkan")

                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["stickerOn"] = True
                                elanks.sendMessage(msg.to," ✔ Check Sticker actived ")

                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["stickerOn"] = False
                                elanks.sendMessage(msg.to," 🚫 Sticker check dinonaktifkan")

                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = True
                                sendMention(msg.to, sender, " User ", "\n➪ Silahkan kirim link grupnya")

                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = False
                                elanks.sendMessage(msg.to," 🚫 Jointicket telah dinonaktifkan")
#============Chatbots================#
                        elif cmd == "chatbot on" or text.lower() == 'chatbots on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["chatbot"] = True
                                elanks.sendMessage(msg.to,"✔ AutoChat Actived")
                                
                        elif cmd == "chatbot off" or text.lower() == 'chatbots off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["chatbot"] = False
                                sdmudra.sendMessage(msg.to," ↘ AutoChat 🚫 nonaktived")
                        
                        elif cmd == 'sepi':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to,"Hooh gara2 kk sih gak mandi (¬_¬)")
                               
                        elif cmd == 'naik':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to,"Moh ah takut di modusin (¬_¬)")

                        elif cmd == 'nah':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to,"Nah neh noh ¯\_(ツ)_/¯ ")                               
                               
                        elif cmd == 'siang':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to,"Iya kk Mat siang mat aktivitas (￣へ￣)") 

                        elif cmd == 'malam':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to,"Iya malam k waktunya bikin ╮(╯▽╰)╭")
                               
                        elif cmd == 'sp':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to," 🔀 Internet gratisan ¯\_(ツ)_/¯")
                               elanks.sendMessage(to,"↘0.005076800537109375 Perdetik")
                               
                        elif cmd == 'assalamualaikum':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to," Waalaikumsalam ")
                               elanks.sendMessage(to,"Σ(O_O；)")

                        elif cmd == 'waalaikumsalam':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to," Moga yg jwb salam jodoh nya banyak ")
                               elanks.sendMessage(to,"╮(╯▽╰)╭ ")

                        elif cmd == 'typo':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to," Tenggelamkan ae yg Typo¯\_(ツ)_/¯")
                               elanks.sendMessage(to,"hehehe")                               
                             
                        elif cmd == 'kuy':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to," Kemana k ¯\_(ツ)_/¯")
       
                        elif cmd == 'pagi':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to,"Pagi juga kk Mandi gih biar gak jones terus ヽ(｀⌒´)ノ")
                               
                        elif cmd == 'halo':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to,"Halo juga kk apa kabar ?Σ(⊙▽⊙) ")
                               
                        elif cmd == 'oke':
                            if wait["chatbot"] == True:
                               elanks.sendMessage(to,"Oke aja deh gue daripada bonyok (╥_╥)")
#===========COMMAND BLACKLIST============#
                        elif cmd == "blc" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                elanks.sendMessage(msg.to,"Tak ada daftar buronan")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +elanks.getContact(m_id).displayName + "\n"
                                elanks.sendMessage(msg.to,"Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))
                        elif cmd == "cban" or text.lower() == 'ampuni':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = elanks.getContacts(wait["blacklist"])
                              mc = "「%i」Bersih" % len(ragets)
                              elanks.sendMessage(msg.to,"Biang kerok " +mc)

                        elif cmd == "antipas on" or text.lower() == 'pas:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["BACKUP CANCELL"] = True
                                elanks.sendMessage(msg.to,"antibypass on...")

                        elif cmd == "antipas off" or text.lower() == 'pas:off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["BACKUP CANCELL"] = False
                                elanks.sendMessage(msg.to,"antibypass off... ")

                        elif cmd == "antijs on" or text.lower() == 'js:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["BACKUP KICK"] = True
                                elanks.sendMessage(msg.to,"antibypass on...")

                        elif cmd == "antijs off" or text.lower() == 'js:off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["BACKUP KICK"] = False
                                elanks.sendMessage(msg.to,"antibypass off... ")     

                        elif cmd == "go":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = [Amid]
                                    elanks.inviteIntoGroup(msg.to, anggota)
                                    elanks1.acceptGroupInvitation(msg.to)
                                except:
                                    pass


                        elif cmd == "stay":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    G = elanks.getGroup(msg.to)
                                    elanks.inviteIntoGroup(msg.to, [Amid])
                                    elanks1.acceptGroupInvitation(msg.to)
                                except:
                                    pass
                                                                                                                              
                        elif cmd == "out":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = elanks.getGroup(msg.to)
                                elanks1.leaveGroup(msg.to)

                        elif cmd == "byee":
                         if msg._from in admin:
                           if msg.toType == 2:
                               group = elanks.getGroup(to)
                               group.preventedJoinByTicket = False
                               elanks.updateGroup(group)
                               invsend = 0
                               ticket = elanks.reissueGroupTicket(to)
                               elanks1.acceptGroupInvitationByTicket(to,format(str(ticket)))
                               group = elanks.getGroup(msg.to)
                               group.preventedJoinByTicket = True
                               elanks1.leaveGroup(msg.to)
                               elanks.updateGroup(group)     

                        elif text.lower() == "addbots":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              gs = [mid,Amid]
                              targets = []
                              for x in gs:
                                  targets.append(x)
                              for target in targets:
                                  try:
                                      elanks.findAndAddContactsByMid(target)
                                      time.sleep(5)
                                      elanks1.findAndAddContactsByMid(target)
                                      time.sleep(5)
                                  except:
                                      elanks.sendMessage(msg.to,"ꜱᴜᴋꜱᴇꜱ ᴀᴅᴅ ʙᴏᴛꜱ")

                        elif msg.text in ["cek kesehatan"]:
                          if msg._from in admin:
                              try:elanks.inviteIntoGroup(to, ["u5d5d8f736b9b730ddab0c89d45cd5585"]);has1 = "OK"
                              except:has1 = "DOWN"
                              if has1 == "OK":sil1 = " SEHAT"
                              else:sil1 = " SAKIT"
                              elanks.sendMessage(to, "STATUS:\n\nMENTAL : {}".format(sil1))                                        

                        elif msg.text in ["cek ajs"]:
                          if msg._from in admin:
                              try:elanks1.inviteIntoGroup(to, ["u5d5d8f736b9b730ddab0c89d45cd5585"]);has1 = "OK"
                              except:has1 = "DOWN"
                              if has1 == "OK":sil1 = " SEHAT"
                              else:sil1 = " SAKIT"
                              elanks.sendMessage(to, "STATUS:\n\nMampus : {}".format(sil1))                                        

                        elif cmd == "potobot":
                          if settings["selfbot"] == True:
                            if msg._from in admin:
                                settings["cfoto"] = True
                                elanks.sendMessage(msg.to,"ᴋɪʀɪᴍ ᴘʜᴏᴛᴏ ᴜɴᴛᴜᴋ Induk & Ajs")  
#===========COMMAND SET TEXT============#
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  elanks.sendMessage(msg.to, "➪Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  elanks.sendMessage(msg.to, "➪Pesan Msg diganti jadi :\n\n{}".format(str(spl)))

                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  elanks.sendMessage(msg.to, " ➪Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  elanks.sendMessage(msg.to, "➪Welcome Msg diganti jadi :\n\n{}".format(str(spl)))

                        elif 'Set leave: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set leave: ','')
                              if spl in [""," ","\n",None]:
                                  elanks.sendMessage(msg.to, "➪Gagal mengganti Leave Msg")
                              else:
                                  wait["leave"] = spl
                                  elanks.sendMessage(msg.to, "➪Leave Msg diganti jadi :\n\n{}".format(str(spl)))

                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  elanks.sendMessage(msg.to, "➪Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  elanks.sendMessage(msg.to, "➪ Respon Msg diganti jadi :\n\n{}".format(str(spl)))
                        elif 'Set ciluk: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set ciluk: ','')
                              if spl in [""," ","\n",None]:
                                  elanks.sendMessage(msg.to, "Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  elanks.sendMessage(msg.to, "➪Sider Msg diganti jadi :\n\n{}".format(str(spl)))
                                  
                        elif 'Set tag: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set tag: ','')
                              if spl in [""," ","\n",None]:
                                  ssmudra.sendMessage(msg.to, "Gagal mengganti Key mention all member")
                              else:
                                  wait["tagall"] = spl
                                  elanks.sendMessage(msg.to, "key mention member ~ :\n\n{}".format(str(spl)))
                                  
 
#==================#  
                        elif cmd == "cancelall":
                          if msg._from in admin:
                            if msg.toType == 2:
                                group = elanks.getGroup(to)
                                if group.invitee is None or group.invitee == []:
                                    elanks.sendMessage(to, "Nothing")
                                else:
                                    invitee = [contact.mid for contact in group.invitee]
                                    for inv in invitee:
                                        elanks.cancelGroupInvitation(to, [inv])
                                        time.sleep(1)
                                    elanks.sendMessage(to, "Canceled {} user".format(str(len(invitee))))
                        elif cmd == "nuke":
                          if msg._from in admin:
                            if msg.toType == 2:
                                group = elanks.getGroup(to)
                                gMembers = [contact.mid for contact in group.members]
                                for i in gMembers:
                                    time.sleep(0.008)
                                    elanks.kickoutFromGroup(to,[i])
                                elanks.sendMessage(to,"Casual elankseasing")
                            else:
                                elanks.sendMessage(to,"failed >_<")

    except Exception as error:
        print (error)
while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                oepoll.setRevision(op.revision)
                thread = threading.Thread(target=bot, args=(op,))
                thread.start()
    except Exception as e:
        print(e)
#==============elanks Bots===========#
#print ("============[Login Bot elanks Sukses]==========")
#thread1 = threading.Thread(target=bot1run)
#thread2 = threading.Thread(target=bot2run)
#thread3 = threading.Thread(target=bot3run)
#thread4 = threading.Thread(target=bot4run)
#thread1.start()
#thread2.start()
#thread3.start()
#thread4.start()









